using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using Microsoft.VisualBasic.ApplicationServices;

namespace NWTimelinerUtils.My;

[EditorBrowsable(EditorBrowsableState.Never)]
[GeneratedCode("MyTemplate", "14.0.0.0")]
internal class MyApplication : ApplicationBase
{
	[DebuggerNonUserCode]
	public MyApplication()
	{
	}
}
