using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils.My;

[CompilerGenerated]
[EditorBrowsable(EditorBrowsableState.Advanced)]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
internal sealed class MySettings : ApplicationSettingsBase
{
	private static MySettings defaultInstance = (MySettings)SettingsBase.Synchronized(new MySettings());

	public static MySettings Default => defaultInstance;

	[DebuggerNonUserCode]
	[UserScopedSetting]
	[DefaultSettingValue("ddd, dd/MM/yyyy HH:mm")]
	public string DATE_FORMAT
	{
		get
		{
			return Conversions.ToString(this["DATE_FORMAT"]);
		}
		set
		{
			this["DATE_FORMAT"] = value;
		}
	}

	[DebuggerNonUserCode]
	[DefaultSettingValue("True")]
	[UserScopedSetting]
	public bool DELETE_PREVIOUS
	{
		get
		{
			return Conversions.ToBoolean(this["DELETE_PREVIOUS"]);
		}
		set
		{
			this["DELETE_PREVIOUS"] = value;
		}
	}

	[DefaultSettingValue("True")]
	[DebuggerNonUserCode]
	[UserScopedSetting]
	public bool TOP_LEVEL_ONLY
	{
		get
		{
			return Conversions.ToBoolean(this["TOP_LEVEL_ONLY"]);
		}
		set
		{
			this["TOP_LEVEL_ONLY"] = value;
		}
	}

	[UserScopedSetting]
	[DefaultSettingValue("False")]
	[DebuggerNonUserCode]
	public bool TIME_ZONED
	{
		get
		{
			return Conversions.ToBoolean(this["TIME_ZONED"]);
		}
		set
		{
			this["TIME_ZONED"] = value;
		}
	}

	[DebuggerNonUserCode]
	[UserScopedSetting]
	[DefaultSettingValue("")]
	public string SELECTED_FIELDS
	{
		get
		{
			return Conversions.ToString(this["SELECTED_FIELDS"]);
		}
		set
		{
			this["SELECTED_FIELDS"] = value;
		}
	}

	[UserScopedSetting]
	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	public string TLSETS_CONFIG
	{
		get
		{
			return Conversions.ToString(this["TLSETS_CONFIG"]);
		}
		set
		{
			this["TLSETS_CONFIG"] = value;
		}
	}

	[DebuggerNonUserCode]
	public MySettings()
	{
	}
}
