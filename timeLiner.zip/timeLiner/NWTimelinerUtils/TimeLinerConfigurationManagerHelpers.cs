using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[StandardModule]
internal sealed class TimeLinerConfigurationManagerHelpers
{
	public const string TIMELINER_CONFIG_NAME = "Timeliner Configuration Manager";

	public const string TIMELINER_CONFIG_HELP_ID = "http://de-software.web/Plugins/Navisworks/Timeliner Utilities/Help/Timeliner Utilities.html#Timeliner Configuration Manager";

	public const string TIMELINER_CONFIG_MSG_TITLE = "Timeliner Configuration Manager";

	public const string TIMELINER_CONFIG_MSG_TITLE_ERROR = "Timeliner Configuration Manager Error";
}
