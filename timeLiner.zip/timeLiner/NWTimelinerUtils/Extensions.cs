using System;
using System.Collections.Generic;
using System.Reflection;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Timeliner;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[StandardModule]
public sealed class Extensions
{
	public static void GetChildren(this TimelinerTask task, ref List<TimelinerTask> Tasks, bool WithSelection)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		foreach (TimelinerTask child in ((GroupItem)task).Children)
		{
			TimelinerTask val = child;
			if (!WithSelection || !val.Selection.IsClear)
			{
				Tasks.Add(val);
			}
			if (((GroupItem)val).Children.Count > 0)
			{
				GetChildren(val, ref Tasks, WithSelection);
			}
		}
	}

	public static object FieldValue(this TimelinerTask t, string FieldName)
	{
		PropertyInfo property = typeof(TimelinerTask).GetProperty(FieldName);
		return property.GetValue(t);
	}

	public static bool IncludesRange(this TimelinerTask t, DateTime? startdate, DateTime? enddate)
	{
		bool? obj;
		if (t.PlannedStartDate.HasValue && startdate.HasValue)
		{
			DateTime? plannedStartDate = t.PlannedStartDate;
			if (!(plannedStartDate.HasValue & startdate.HasValue))
			{
				obj = null;
			}
			else
			{
				bool? flag = DateTime.Compare(plannedStartDate.GetValueOrDefault(), startdate.GetValueOrDefault()) <= 0;
				obj = flag;
			}
		}
		else
		{
			bool? flag2 = true;
			obj = flag2;
		}
		bool flag3 = (bool)obj;
		bool? obj2;
		if (t.PlannedEndDate.HasValue && enddate.HasValue)
		{
			DateTime? plannedStartDate = t.PlannedEndDate;
			if (!(plannedStartDate.HasValue & enddate.HasValue))
			{
				obj2 = null;
			}
			else
			{
				bool? flag2 = DateTime.Compare(plannedStartDate.GetValueOrDefault(), enddate.GetValueOrDefault()) >= 0;
				obj2 = flag2;
			}
		}
		else
		{
			bool? flag = true;
			obj2 = flag;
		}
		bool flag4 = (bool)obj2;
		return (flag3 && flag4) ? true : false;
	}

	public static bool IsSameTask(this TimelinerTask t, DateTime? startdate, DateTime? enddate, string taskname)
	{
		if (Operators.CompareString(((SavedItem)t).DisplayName, taskname, TextCompare: false) != 0)
		{
			return false;
		}
		if (!object.Equals(t.PlannedStartDate, startdate))
		{
			return false;
		}
		if (!object.Equals(t.PlannedEndDate, enddate))
		{
			return false;
		}
		return true;
	}
}
