using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.DocumentParts;
using Autodesk.Navisworks.Api.Timeliner;
using Microsoft.VisualBasic.CompilerServices;
using NWTimelinerUtils.My;
using NWTimelinerUtils.My.Resources;

namespace NWTimelinerUtils;

[DesignerGenerated]
public class TimelinerAssistantControl : UserControl
{
	private IContainer components;

	[AccessedThroughProperty("EndLbl")]
	private Label _EndLbl;

	[AccessedThroughProperty("StartLbl")]
	private Label _StartLbl;

	[AccessedThroughProperty("ObjectTb")]
	private TextBox _ObjectTb;

	[AccessedThroughProperty("Label2")]
	private Label _Label2;

	[AccessedThroughProperty("SyncIDTb")]
	private TextBox _SyncIDTb;

	[AccessedThroughProperty("DisplayIDTb")]
	private TextBox _DisplayIDTb;

	[AccessedThroughProperty("Label4")]
	private Label _Label4;

	[AccessedThroughProperty("Label3")]
	private Label _Label3;

	[AccessedThroughProperty("ToolTip1")]
	private ToolTip _ToolTip1;

	[AccessedThroughProperty("EndTb")]
	private TextBox _EndTb;

	[AccessedThroughProperty("StartTb")]
	private TextBox _StartTb;

	[AccessedThroughProperty("SimulationTaskTypeCb")]
	private ComboBox _SimulationTaskTypeCb;

	[AccessedThroughProperty("Label1")]
	private Label _Label1;

	[AccessedThroughProperty("TaskSelectionLlbl")]
	private LinkLabel _TaskSelectionLlbl;

	[AccessedThroughProperty("Label5")]
	private Label _Label5;

	[AccessedThroughProperty("DateTimeCM")]
	private ContextMenuStrip _DateTimeCM;

	[AccessedThroughProperty("DateTimeFormatMI")]
	private ToolStripComboBox _DateTimeFormatMI;

	[AccessedThroughProperty("GetTimelinerParentBtn")]
	private Button _GetTimelinerParentBtn;

	[AccessedThroughProperty("TableLayoutPanel1")]
	private TableLayoutPanel _TableLayoutPanel1;

	[AccessedThroughProperty("NavigationTlyt")]
	private TableLayoutPanel _NavigationTlyt;

	[AccessedThroughProperty("PreviousTaskLbl")]
	private LinkLabel _PreviousTaskLbl;

	[AccessedThroughProperty("NextTaskLbl")]
	private LinkLabel _NextTaskLbl;

	[AccessedThroughProperty("CounterLbl")]
	private Label _CounterLbl;

	[AccessedThroughProperty("SetSelectionBtn")]
	private Button _SetSelectionBtn;

	[AccessedThroughProperty("Label6")]
	private Label _Label6;

	[AccessedThroughProperty("WBSTvw")]
	private TreeView _WBSTvw;

	private TimelinerTask _SelectedTask;

	private List<TimelinerTask> _Tasks;

	private bool _IsResolvingTaskSelection;

	private const string CAT_TIMELINER = "Timeliner";

	private const string TASK_CONTAINED_INDEX = "Contained in Task:{0}";

	private const string TASK_CONTAINED_START_INDEX = "Contained in Task Start (Planned):{0}";

	private const string TASK_CONTAINED_END_INDEX = "Contained in Task End (Planned):{0}";

	private const string TASK_ATTACHED_INDEX = "Attached to Task:{0}";

	internal virtual Label EndLbl
	{
		[DebuggerNonUserCode]
		get
		{
			return _EndLbl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_EndLbl = value;
		}
	}

	internal virtual Label StartLbl
	{
		[DebuggerNonUserCode]
		get
		{
			return _StartLbl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_StartLbl = value;
		}
	}

	internal virtual TextBox ObjectTb
	{
		[DebuggerNonUserCode]
		get
		{
			return _ObjectTb;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_ObjectTb = value;
		}
	}

	internal virtual Label Label2
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label2 = value;
		}
	}

	internal virtual TextBox SyncIDTb
	{
		[DebuggerNonUserCode]
		get
		{
			return _SyncIDTb;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_SyncIDTb = value;
		}
	}

	internal virtual TextBox DisplayIDTb
	{
		[DebuggerNonUserCode]
		get
		{
			return _DisplayIDTb;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_DisplayIDTb = value;
		}
	}

	internal virtual Label Label4
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label4;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label4 = value;
		}
	}

	internal virtual Label Label3
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label3 = value;
		}
	}

	internal virtual ToolTip ToolTip1
	{
		[DebuggerNonUserCode]
		get
		{
			return _ToolTip1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_ToolTip1 = value;
		}
	}

	internal virtual TextBox EndTb
	{
		[DebuggerNonUserCode]
		get
		{
			return _EndTb;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_EndTb = value;
		}
	}

	internal virtual TextBox StartTb
	{
		[DebuggerNonUserCode]
		get
		{
			return _StartTb;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_StartTb = value;
		}
	}

	internal virtual ComboBox SimulationTaskTypeCb
	{
		[DebuggerNonUserCode]
		get
		{
			return _SimulationTaskTypeCb;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = SimulationTaskTypeCb_SelectedIndexChanged;
			if (_SimulationTaskTypeCb != null)
			{
				_SimulationTaskTypeCb.SelectedIndexChanged -= value2;
			}
			_SimulationTaskTypeCb = value;
			if (_SimulationTaskTypeCb != null)
			{
				_SimulationTaskTypeCb.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual Label Label1
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label1 = value;
		}
	}

	internal virtual LinkLabel TaskSelectionLlbl
	{
		[DebuggerNonUserCode]
		get
		{
			return _TaskSelectionLlbl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			LinkLabelLinkClickedEventHandler value2 = TaskSelectionLlbl_LinkClicked;
			if (_TaskSelectionLlbl != null)
			{
				_TaskSelectionLlbl.LinkClicked -= value2;
			}
			_TaskSelectionLlbl = value;
			if (_TaskSelectionLlbl != null)
			{
				_TaskSelectionLlbl.LinkClicked += value2;
			}
		}
	}

	internal virtual Label Label5
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label5;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label5 = value;
		}
	}

	internal virtual ContextMenuStrip DateTimeCM
	{
		[DebuggerNonUserCode]
		get
		{
			return _DateTimeCM;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_DateTimeCM = value;
		}
	}

	internal virtual ToolStripComboBox DateTimeFormatMI
	{
		[DebuggerNonUserCode]
		get
		{
			return _DateTimeFormatMI;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_DateTimeFormatMI = value;
		}
	}

	internal virtual Button GetTimelinerParentBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _GetTimelinerParentBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = GetTimelinerParentBtn_Click;
			if (_GetTimelinerParentBtn != null)
			{
				_GetTimelinerParentBtn.Click -= value2;
			}
			_GetTimelinerParentBtn = value;
			if (_GetTimelinerParentBtn != null)
			{
				_GetTimelinerParentBtn.Click += value2;
			}
		}
	}

	internal virtual TableLayoutPanel TableLayoutPanel1
	{
		[DebuggerNonUserCode]
		get
		{
			return _TableLayoutPanel1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_TableLayoutPanel1 = value;
		}
	}

	internal virtual TableLayoutPanel NavigationTlyt
	{
		[DebuggerNonUserCode]
		get
		{
			return _NavigationTlyt;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_NavigationTlyt = value;
		}
	}

	internal virtual LinkLabel PreviousTaskLbl
	{
		[DebuggerNonUserCode]
		get
		{
			return _PreviousTaskLbl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			LinkLabelLinkClickedEventHandler value2 = PreviousTaskLbl_LinkClicked;
			if (_PreviousTaskLbl != null)
			{
				_PreviousTaskLbl.LinkClicked -= value2;
			}
			_PreviousTaskLbl = value;
			if (_PreviousTaskLbl != null)
			{
				_PreviousTaskLbl.LinkClicked += value2;
			}
		}
	}

	internal virtual LinkLabel NextTaskLbl
	{
		[DebuggerNonUserCode]
		get
		{
			return _NextTaskLbl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			LinkLabelLinkClickedEventHandler value2 = NextTaskLbl_LinkClicked;
			if (_NextTaskLbl != null)
			{
				_NextTaskLbl.LinkClicked -= value2;
			}
			_NextTaskLbl = value;
			if (_NextTaskLbl != null)
			{
				_NextTaskLbl.LinkClicked += value2;
			}
		}
	}

	internal virtual Label CounterLbl
	{
		[DebuggerNonUserCode]
		get
		{
			return _CounterLbl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_CounterLbl = value;
		}
	}

	internal virtual Button SetSelectionBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _SetSelectionBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = SetSelectionBtn_Click;
			if (_SetSelectionBtn != null)
			{
				_SetSelectionBtn.Click -= value2;
			}
			_SetSelectionBtn = value;
			if (_SetSelectionBtn != null)
			{
				_SetSelectionBtn.Click += value2;
			}
		}
	}

	internal virtual Label Label6
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label6;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label6 = value;
		}
	}

	internal virtual TreeView WBSTvw
	{
		[DebuggerNonUserCode]
		get
		{
			return _WBSTvw;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_WBSTvw = value;
		}
	}

	public TimelinerTask SelectedTask
	{
		get
		{
			return _SelectedTask;
		}
		set
		{
			_SelectedTask = value;
			BindTask(value);
		}
	}

	public List<TimelinerTask> Tasks => _Tasks;

	public TimelinerAssistantControl()
	{
		base.Load += TimelinerAssistantControl_Load;
		_Tasks = new List<TimelinerTask>();
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		this.TaskSelectionLlbl = new System.Windows.Forms.LinkLabel();
		this.SimulationTaskTypeCb = new System.Windows.Forms.ComboBox();
		this.Label1 = new System.Windows.Forms.Label();
		this.EndTb = new System.Windows.Forms.TextBox();
		this.DateTimeCM = new System.Windows.Forms.ContextMenuStrip(this.components);
		this.DateTimeFormatMI = new System.Windows.Forms.ToolStripComboBox();
		this.StartTb = new System.Windows.Forms.TextBox();
		this.SyncIDTb = new System.Windows.Forms.TextBox();
		this.DisplayIDTb = new System.Windows.Forms.TextBox();
		this.ObjectTb = new System.Windows.Forms.TextBox();
		this.Label2 = new System.Windows.Forms.Label();
		this.Label4 = new System.Windows.Forms.Label();
		this.Label3 = new System.Windows.Forms.Label();
		this.EndLbl = new System.Windows.Forms.Label();
		this.Label5 = new System.Windows.Forms.Label();
		this.StartLbl = new System.Windows.Forms.Label();
		this.ToolTip1 = new System.Windows.Forms.ToolTip(this.components);
		this.GetTimelinerParentBtn = new System.Windows.Forms.Button();
		this.SetSelectionBtn = new System.Windows.Forms.Button();
		this.TableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
		this.NavigationTlyt = new System.Windows.Forms.TableLayoutPanel();
		this.PreviousTaskLbl = new System.Windows.Forms.LinkLabel();
		this.NextTaskLbl = new System.Windows.Forms.LinkLabel();
		this.CounterLbl = new System.Windows.Forms.Label();
		this.Label6 = new System.Windows.Forms.Label();
		this.WBSTvw = new System.Windows.Forms.TreeView();
		this.DateTimeCM.SuspendLayout();
		this.TableLayoutPanel1.SuspendLayout();
		this.NavigationTlyt.SuspendLayout();
		this.SuspendLayout();
		this.TaskSelectionLlbl.AutoSize = true;
		this.TaskSelectionLlbl.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.LinkLabel taskSelectionLlbl = this.TaskSelectionLlbl;
		System.Drawing.Point location = new System.Drawing.Point(77, 60);
		taskSelectionLlbl.Location = location;
		this.TaskSelectionLlbl.Name = "TaskSelectionLlbl";
		System.Windows.Forms.LinkLabel taskSelectionLlbl2 = this.TaskSelectionLlbl;
		System.Drawing.Size size = new System.Drawing.Size(168, 29);
		taskSelectionLlbl2.Size = size;
		this.TaskSelectionLlbl.TabIndex = 12;
		this.TaskSelectionLlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.ToolTip1.SetToolTip(this.TaskSelectionLlbl, "Select Task Attachment");
		this.SimulationTaskTypeCb.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.TableLayoutPanel1.SetColumnSpan(this.SimulationTaskTypeCb, 2);
		this.SimulationTaskTypeCb.FormattingEnabled = true;
		System.Windows.Forms.ComboBox simulationTaskTypeCb = this.SimulationTaskTypeCb;
		location = new System.Drawing.Point(74, 276);
		simulationTaskTypeCb.Location = location;
		this.SimulationTaskTypeCb.Name = "SimulationTaskTypeCb";
		System.Windows.Forms.ComboBox simulationTaskTypeCb2 = this.SimulationTaskTypeCb;
		size = new System.Drawing.Size(197, 21);
		simulationTaskTypeCb2.Size = size;
		this.SimulationTaskTypeCb.TabIndex = 11;
		this.Label1.AutoSize = true;
		this.Label1.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label label = this.Label1;
		location = new System.Drawing.Point(13, 150);
		label.Location = location;
		this.Label1.Name = "Label1";
		System.Windows.Forms.Label label2 = this.Label1;
		size = new System.Drawing.Size(58, 27);
		label2.Size = size;
		this.Label1.TabIndex = 10;
		this.Label1.Text = "Type";
		this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.EndTb.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.TableLayoutPanel1.SetColumnSpan(this.EndTb, 2);
		this.EndTb.ContextMenuStrip = this.DateTimeCM;
		System.Windows.Forms.TextBox endTb = this.EndTb;
		location = new System.Drawing.Point(74, 127);
		endTb.Location = location;
		this.EndTb.Name = "EndTb";
		this.EndTb.ReadOnly = true;
		System.Windows.Forms.TextBox endTb2 = this.EndTb;
		size = new System.Drawing.Size(197, 22);
		endTb2.Size = size;
		this.EndTb.TabIndex = 9;
		this.ToolTip1.SetToolTip(this.EndTb, "End Date of the Task, Right Click\r\nto Change Date Formating...");
		this.DateTimeCM.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.DateTimeFormatMI });
		this.DateTimeCM.Name = "DateTimeCM";
		System.Windows.Forms.ContextMenuStrip dateTimeCM = this.DateTimeCM;
		size = new System.Drawing.Size(261, 31);
		dateTimeCM.Size = size;
		this.DateTimeFormatMI.AutoSize = false;
		this.DateTimeFormatMI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.DateTimeFormatMI.DropDownWidth = 200;
		this.DateTimeFormatMI.Items.AddRange(new object[4] { "dddd, dd MMMM yyyy HH:mm:ss zzz", "ddd, dd/MM/yyyy HH:mm", "dd/MM/yy h:mm tt", "d/M/yy H:mm" });
		this.DateTimeFormatMI.Name = "DateTimeFormatMI";
		System.Windows.Forms.ToolStripComboBox dateTimeFormatMI = this.DateTimeFormatMI;
		size = new System.Drawing.Size(200, 23);
		dateTimeFormatMI.Size = size;
		this.StartTb.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.TableLayoutPanel1.SetColumnSpan(this.StartTb, 2);
		this.StartTb.ContextMenuStrip = this.DateTimeCM;
		System.Windows.Forms.TextBox startTb = this.StartTb;
		location = new System.Drawing.Point(74, 101);
		startTb.Location = location;
		this.StartTb.Name = "StartTb";
		this.StartTb.ReadOnly = true;
		System.Windows.Forms.TextBox startTb2 = this.StartTb;
		size = new System.Drawing.Size(197, 22);
		startTb2.Size = size;
		this.StartTb.TabIndex = 9;
		this.ToolTip1.SetToolTip(this.StartTb, "Start Date of the Task, Right Click\r\nto Change Date Formating...");
		this.SyncIDTb.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.TableLayoutPanel1.SetColumnSpan(this.SyncIDTb, 2);
		System.Windows.Forms.TextBox syncIDTb = this.SyncIDTb;
		location = new System.Drawing.Point(74, 216);
		syncIDTb.Location = location;
		this.SyncIDTb.Name = "SyncIDTb";
		this.SyncIDTb.ReadOnly = true;
		System.Windows.Forms.TextBox syncIDTb2 = this.SyncIDTb;
		size = new System.Drawing.Size(197, 22);
		syncIDTb2.Size = size;
		this.SyncIDTb.TabIndex = 7;
		this.DisplayIDTb.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.TableLayoutPanel1.SetColumnSpan(this.DisplayIDTb, 2);
		System.Windows.Forms.TextBox displayIDTb = this.DisplayIDTb;
		location = new System.Drawing.Point(74, 190);
		displayIDTb.Location = location;
		this.DisplayIDTb.Name = "DisplayIDTb";
		this.DisplayIDTb.ReadOnly = true;
		System.Windows.Forms.TextBox displayIDTb2 = this.DisplayIDTb;
		size = new System.Drawing.Size(197, 22);
		displayIDTb2.Size = size;
		this.DisplayIDTb.TabIndex = 7;
		this.ObjectTb.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		System.Windows.Forms.TextBox objectTb = this.ObjectTb;
		location = new System.Drawing.Point(77, 13);
		objectTb.Location = location;
		this.ObjectTb.Name = "ObjectTb";
		this.ObjectTb.ReadOnly = true;
		System.Windows.Forms.TextBox objectTb2 = this.ObjectTb;
		size = new System.Drawing.Size(168, 22);
		objectTb2.Size = size;
		this.ObjectTb.TabIndex = 6;
		this.Label2.AutoSize = true;
		this.Label2.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label label3 = this.Label2;
		location = new System.Drawing.Point(13, 10);
		label3.Location = location;
		this.Label2.Name = "Label2";
		System.Windows.Forms.Label label4 = this.Label2;
		size = new System.Drawing.Size(58, 29);
		label4.Size = size;
		this.Label2.TabIndex = 5;
		this.Label2.Text = "Object";
		this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.Label4.AutoSize = true;
		this.Label4.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label label5 = this.Label4;
		location = new System.Drawing.Point(13, 213);
		label5.Location = location;
		this.Label4.Name = "Label4";
		System.Windows.Forms.Label label6 = this.Label4;
		size = new System.Drawing.Size(58, 28);
		label6.Size = size;
		this.Label4.TabIndex = 3;
		this.Label4.Text = "Sync ID";
		this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.Label3.AutoSize = true;
		this.Label3.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label label7 = this.Label3;
		location = new System.Drawing.Point(13, 187);
		label7.Location = location;
		this.Label3.Name = "Label3";
		System.Windows.Forms.Label label8 = this.Label3;
		size = new System.Drawing.Size(58, 28);
		label8.Size = size;
		this.Label3.TabIndex = 3;
		this.Label3.Text = "Display ID";
		this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.EndLbl.AutoSize = true;
		this.EndLbl.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label endLbl = this.EndLbl;
		location = new System.Drawing.Point(13, 124);
		endLbl.Location = location;
		this.EndLbl.Name = "EndLbl";
		System.Windows.Forms.Label endLbl2 = this.EndLbl;
		size = new System.Drawing.Size(58, 28);
		endLbl2.Size = size;
		this.EndLbl.TabIndex = 3;
		this.EndLbl.Text = "End";
		this.EndLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.Label5.AutoSize = true;
		this.Label5.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label label9 = this.Label5;
		location = new System.Drawing.Point(13, 60);
		label9.Location = location;
		this.Label5.Name = "Label5";
		System.Windows.Forms.Label label10 = this.Label5;
		size = new System.Drawing.Size(58, 29);
		label10.Size = size;
		this.Label5.TabIndex = 3;
		this.Label5.Text = "Task(s)";
		this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.StartLbl.AutoSize = true;
		this.StartLbl.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label startLbl = this.StartLbl;
		location = new System.Drawing.Point(13, 221);
		startLbl.Location = location;
		this.StartLbl.Name = "StartLbl";
		System.Windows.Forms.Label startLbl2 = this.StartLbl;
		size = new System.Drawing.Size(58, 28);
		startLbl2.Size = size;
		this.StartLbl.TabIndex = 3;
		this.StartLbl.Text = "Start";
		this.StartLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.GetTimelinerParentBtn.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.GetTimelinerParentBtn.Image = NWTimelinerUtils.My.Resources.Resources.SelectTimelinerParent;
		System.Windows.Forms.Button getTimelinerParentBtn = this.GetTimelinerParentBtn;
		location = new System.Drawing.Point(251, 13);
		getTimelinerParentBtn.Location = location;
		this.GetTimelinerParentBtn.Name = "GetTimelinerParentBtn";
		System.Windows.Forms.Button getTimelinerParentBtn2 = this.GetTimelinerParentBtn;
		size = new System.Drawing.Size(23, 23);
		getTimelinerParentBtn2.Size = size;
		this.GetTimelinerParentBtn.TabIndex = 13;
		this.ToolTip1.SetToolTip(this.GetTimelinerParentBtn, "Select Parent attached to Task");
		this.GetTimelinerParentBtn.UseVisualStyleBackColor = true;
		this.SetSelectionBtn.Dock = System.Windows.Forms.DockStyle.Top;
		this.SetSelectionBtn.Image = NWTimelinerUtils.My.Resources.Resources.Add_16;
		System.Windows.Forms.Button setSelectionBtn = this.SetSelectionBtn;
		location = new System.Drawing.Point(251, 63);
		setSelectionBtn.Location = location;
		this.SetSelectionBtn.Name = "SetSelectionBtn";
		System.Windows.Forms.Button setSelectionBtn2 = this.SetSelectionBtn;
		size = new System.Drawing.Size(23, 23);
		setSelectionBtn2.Size = size;
		this.SetSelectionBtn.TabIndex = 15;
		this.ToolTip1.SetToolTip(this.SetSelectionBtn, "Set current selection as task selection");
		this.SetSelectionBtn.UseVisualStyleBackColor = true;
		this.TableLayoutPanel1.ColumnCount = 3;
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100f));
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
		this.TableLayoutPanel1.Controls.Add(this.SyncIDTb, 1, 10);
		this.TableLayoutPanel1.Controls.Add(this.SimulationTaskTypeCb, 1, 7);
		this.TableLayoutPanel1.Controls.Add(this.Label4, 0, 10);
		this.TableLayoutPanel1.Controls.Add(this.DisplayIDTb, 1, 9);
		this.TableLayoutPanel1.Controls.Add(this.GetTimelinerParentBtn, 2, 0);
		this.TableLayoutPanel1.Controls.Add(this.Label1, 0, 7);
		this.TableLayoutPanel1.Controls.Add(this.Label3, 0, 9);
		this.TableLayoutPanel1.Controls.Add(this.Label5, 0, 2);
		this.TableLayoutPanel1.Controls.Add(this.EndTb, 1, 6);
		this.TableLayoutPanel1.Controls.Add(this.TaskSelectionLlbl, 1, 2);
		this.TableLayoutPanel1.Controls.Add(this.StartTb, 1, 5);
		this.TableLayoutPanel1.Controls.Add(this.ObjectTb, 1, 0);
		this.TableLayoutPanel1.Controls.Add(this.Label2, 0, 0);
		this.TableLayoutPanel1.Controls.Add(this.StartLbl, 0, 5);
		this.TableLayoutPanel1.Controls.Add(this.EndLbl, 0, 6);
		this.TableLayoutPanel1.Controls.Add(this.NavigationTlyt, 1, 1);
		this.TableLayoutPanel1.Controls.Add(this.SetSelectionBtn, 2, 2);
		this.TableLayoutPanel1.Controls.Add(this.Label6, 0, 3);
		this.TableLayoutPanel1.Controls.Add(this.WBSTvw, 1, 3);
		this.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel = this.TableLayoutPanel1;
		location = new System.Drawing.Point(0, 0);
		tableLayoutPanel.Location = location;
		this.TableLayoutPanel1.Name = "TableLayoutPanel1";
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel2 = this.TableLayoutPanel1;
		System.Windows.Forms.Padding padding = new System.Windows.Forms.Padding(10);
		tableLayoutPanel2.Padding = padding;
		this.TableLayoutPanel1.RowCount = 12;
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100f));
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9f));
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10f));
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel3 = this.TableLayoutPanel1;
		size = new System.Drawing.Size(287, 372);
		tableLayoutPanel3.Size = size;
		this.TableLayoutPanel1.TabIndex = 3;
		this.NavigationTlyt.AutoSize = true;
		this.NavigationTlyt.ColumnCount = 3;
		this.NavigationTlyt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
		this.NavigationTlyt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30f));
		this.NavigationTlyt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
		this.NavigationTlyt.Controls.Add(this.PreviousTaskLbl, 0, 0);
		this.NavigationTlyt.Controls.Add(this.NextTaskLbl, 2, 0);
		this.NavigationTlyt.Controls.Add(this.CounterLbl, 1, 0);
		this.NavigationTlyt.Dock = System.Windows.Forms.DockStyle.Left;
		System.Windows.Forms.TableLayoutPanel navigationTlyt = this.NavigationTlyt;
		location = new System.Drawing.Point(74, 44);
		navigationTlyt.Location = location;
		System.Windows.Forms.TableLayoutPanel navigationTlyt2 = this.NavigationTlyt;
		padding = new System.Windows.Forms.Padding(0, 5, 0, 3);
		navigationTlyt2.Margin = padding;
		this.NavigationTlyt.Name = "NavigationTlyt";
		this.NavigationTlyt.RowCount = 1;
		this.NavigationTlyt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100f));
		System.Windows.Forms.TableLayoutPanel navigationTlyt3 = this.NavigationTlyt;
		size = new System.Drawing.Size(72, 13);
		navigationTlyt3.Size = size;
		this.NavigationTlyt.TabIndex = 14;
		this.NavigationTlyt.Visible = false;
		this.PreviousTaskLbl.AutoSize = true;
		this.PreviousTaskLbl.Dock = System.Windows.Forms.DockStyle.Fill;
		this.PreviousTaskLbl.Enabled = false;
		this.PreviousTaskLbl.LinkColor = System.Drawing.Color.Teal;
		System.Windows.Forms.LinkLabel previousTaskLbl = this.PreviousTaskLbl;
		location = new System.Drawing.Point(3, 0);
		previousTaskLbl.Location = location;
		this.PreviousTaskLbl.Name = "PreviousTaskLbl";
		System.Windows.Forms.LinkLabel previousTaskLbl2 = this.PreviousTaskLbl;
		size = new System.Drawing.Size(15, 13);
		previousTaskLbl2.Size = size;
		this.PreviousTaskLbl.TabIndex = 0;
		this.PreviousTaskLbl.TabStop = true;
		this.PreviousTaskLbl.Text = "<";
		this.PreviousTaskLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.NextTaskLbl.AutoSize = true;
		this.NextTaskLbl.Dock = System.Windows.Forms.DockStyle.Fill;
		this.NextTaskLbl.Enabled = false;
		this.NextTaskLbl.LinkColor = System.Drawing.Color.Teal;
		System.Windows.Forms.LinkLabel nextTaskLbl = this.NextTaskLbl;
		location = new System.Drawing.Point(54, 0);
		nextTaskLbl.Location = location;
		this.NextTaskLbl.Name = "NextTaskLbl";
		System.Windows.Forms.LinkLabel nextTaskLbl2 = this.NextTaskLbl;
		size = new System.Drawing.Size(15, 13);
		nextTaskLbl2.Size = size;
		this.NextTaskLbl.TabIndex = 0;
		this.NextTaskLbl.TabStop = true;
		this.NextTaskLbl.Text = ">";
		this.NextTaskLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.CounterLbl.AutoSize = true;
		this.CounterLbl.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label counterLbl = this.CounterLbl;
		location = new System.Drawing.Point(24, 0);
		counterLbl.Location = location;
		this.CounterLbl.Name = "CounterLbl";
		System.Windows.Forms.Label counterLbl2 = this.CounterLbl;
		size = new System.Drawing.Size(24, 13);
		counterLbl2.Size = size;
		this.CounterLbl.TabIndex = 1;
		this.CounterLbl.Text = "0/0";
		this.CounterLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.Label6.AutoSize = true;
		this.Label6.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Label label11 = this.Label6;
		location = new System.Drawing.Point(13, 94);
		label11.Location = location;
		System.Windows.Forms.Label label12 = this.Label6;
		padding = new System.Windows.Forms.Padding(3, 5, 3, 0);
		label12.Margin = padding;
		this.Label6.Name = "Label6";
		System.Windows.Forms.Label label13 = this.Label6;
		size = new System.Drawing.Size(55, 118);
		label13.Size = size;
		this.Label6.TabIndex = 16;
		this.Label6.Text = "WBS";
		this.TableLayoutPanel1.SetColumnSpan(this.WBSTvw, 2);
		this.WBSTvw.Dock = System.Windows.Forms.DockStyle.Fill;
		this.WBSTvw.Indent = 10;
		System.Windows.Forms.TreeView wBSTvw = this.WBSTvw;
		location = new System.Drawing.Point(74, 92);
		wBSTvw.Location = location;
		this.WBSTvw.Name = "WBSTvw";
		System.Windows.Forms.TreeView wBSTvw2 = this.WBSTvw;
		size = new System.Drawing.Size(200, 117);
		wBSTvw2.Size = size;
		this.WBSTvw.TabIndex = 17;
		System.Drawing.SizeF sizeF = new System.Drawing.SizeF(6f, 13f);
		this.AutoScaleDimensions = sizeF;
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.Controls.Add(this.TableLayoutPanel1);
		this.Font = new System.Drawing.Font("Segoe UI", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.Name = "TimelinerAssistantControl";
		size = new System.Drawing.Size(287, 372);
		this.Size = size;
		this.DateTimeCM.ResumeLayout(false);
		this.TableLayoutPanel1.ResumeLayout(false);
		this.TableLayoutPanel1.PerformLayout();
		this.NavigationTlyt.ResumeLayout(false);
		this.NavigationTlyt.PerformLayout();
		this.ResumeLayout(false);
	}

	private void BindTask(TimelinerTask task)
	{
		Selection val = DocumentCurrentSelection.op_Implicit(Application.ActiveDocument.CurrentSelection);
		checked
		{
			if (task != null && !val.IsClear)
			{
				ModelItem first = val.GetSelectedItems().First;
				ObjectTb.Text = first.DisplayName;
				TaskSelectionLlbl.Text = ((SavedItem)task).DisplayName;
				FormatDates(MySettingsProperty.Settings.DATE_FORMAT);
				DisplayIDTb.Text = task.DisplayId;
				SyncIDTb.Text = task.SynchronizationId;
				SimulationTaskTypeCb.SelectedItem = task.SimulationTaskTypeName;
				int num = _Tasks.IndexOf(task);
				DataProperty val2 = first.PropertyCategories.FindPropertyByDisplayName("Timeliner", $"Attached to Task:{num}");
				GetTimelinerParentBtn.Enabled = val2 == null;
				CounterLbl.Text = $"{num + 1}/{_Tasks.Count}";
				NavigationTlyt.Visible = _Tasks.Count > 1;
				PreviousTaskLbl.Enabled = num > 0;
				NextTaskLbl.Enabled = num < _Tasks.Count - 1;
				SetSelectionBtn.Enabled = Application.ActiveDocument.CurrentSelection.IsEmpty;
			}
			else
			{
				ObjectTb.Text = "";
				TaskSelectionLlbl.Text = "<No Task found>";
				StartTb.Text = "";
				EndTb.Text = "";
				DisplayIDTb.Text = "";
				SyncIDTb.Text = "";
				SimulationTaskTypeCb.SelectedItem = "";
				GetTimelinerParentBtn.Enabled = false;
				CounterLbl.Text = "0/0";
				NavigationTlyt.Visible = false;
				PreviousTaskLbl.Enabled = false;
				NextTaskLbl.Enabled = false;
				SetSelectionBtn.Enabled = false;
			}
			BuildWBSTree(task);
		}
	}

	private void BuildWBSTree(TimelinerTask task)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Expected O, but got Unknown
		WBSTvw.Nodes.Clear();
		if (task == null)
		{
			return;
		}
		GroupItem val = ((SavedItem)task).Parent;
		TreeNode treeNode = null;
		while (val != null && val is TimelinerTask)
		{
			TimelinerTask val2 = (TimelinerTask)val;
			TreeNode treeNode2 = new TreeNode();
			treeNode2.Name = val2.SynchronizationId;
			treeNode2.Text = ((SavedItem)val2).DisplayName;
			treeNode2.Tag = val2;
			TreeNode treeNode3 = treeNode2;
			if (treeNode != null)
			{
				treeNode3.Nodes.Add(treeNode);
			}
			treeNode = treeNode3;
			val = ((SavedItem)val).Parent;
		}
		if (treeNode != null)
		{
			WBSTvw.Nodes.Add(treeNode);
		}
		WBSTvw.ExpandAll();
	}

	private void TimelinerAssistantControl_Load(object sender, EventArgs e)
	{
		DateTimeFormatMI.ComboBox.SelectedItem = MySettingsProperty.Settings.DATE_FORMAT;
		DateTimeFormatMI.SelectedIndexChanged += DateTimeFormatMI_SelectedIndexChanged;
		Application.ActiveDocument.CurrentSelection.Changed += NavisSelection_Changed;
	}

	private void TaskSelectionLlbl_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		try
		{
			_IsResolvingTaskSelection = true;
			if (SelectedTask != null)
			{
				Application.ActiveDocument.CurrentSelection.CopyFrom(SelectedTask.Selection.GetSelectedItems(Application.ActiveDocument));
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(Application.Gui.MainWindow, ex2.Message);
			ProjectData.ClearProjectError();
		}
		finally
		{
			_IsResolvingTaskSelection = false;
		}
	}

	private void SetSelectionBtn_Click(object sender, EventArgs e)
	{
		try
		{
			if (SelectedTask == null || Application.ActiveDocument.CurrentSelection.IsEmpty || MessageBox.Show("Changing task selection from the Timeliner Assistant will reset your Timeliner Collapse/Expand State. Do you want to continue?", "Timeliner Assistant", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
			{
				return;
			}
			try
			{
				SetTaskSelection(SelectedTask, (IEnumerable<ModelItem>)Application.ActiveDocument.CurrentSelection.SelectedItems);
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show("Selection cannot be changed.\r\n" + ex2.Message, "Timeliner Assistant Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
		catch (Exception ex3)
		{
			ProjectData.SetProjectError(ex3);
			Exception ex4 = ex3;
			MessageBox.Show(Application.Gui.MainWindow, ex4.Message);
			ProjectData.ClearProjectError();
		}
	}

	private void SimulationTaskTypeCb_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (SelectedTask == null || Operators.CompareString(SelectedTask.SimulationTaskTypeName, SimulationTaskTypeCb.Text, TextCompare: false) == 0)
		{
			return;
		}
		bool flag = false;
		if (MessageBox.Show("Changing task type from the Timeliner Assistant will reset your Timeliner Collapse/Expand State. Do you want to continue?", "Timeliner Assistant", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
		{
			try
			{
				ChangeTaskType(SelectedTask, SimulationTaskTypeCb.Text);
				flag = true;
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show("Type cannot be changed.\r\n" + ex2.Message, "Timeliner Assistant Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
		if (!flag)
		{
			SimulationTaskTypeCb.SelectedItem = SelectedTask.SimulationTaskTypeName;
		}
	}

	private void DateTimeFormatMI_SelectedIndexChanged(object sender, EventArgs e)
	{
		MySettingsProperty.Settings.DATE_FORMAT = DateTimeFormatMI.Text;
		if (SelectedTask != null)
		{
			FormatDates(MySettingsProperty.Settings.DATE_FORMAT);
		}
	}

	private void GetTimelinerParentBtn_Click(object sender, EventArgs e)
	{
		if (Application.ActiveDocument.CurrentSelection != null)
		{
			ModelItem timelinerParent = GetTimelinerParent(Application.ActiveDocument.CurrentSelection.SelectedItems[0]);
			if (timelinerParent != null)
			{
				Application.ActiveDocument.CurrentSelection.CopyFrom((IEnumerable<ModelItem>)(object)new ModelItem[1] { timelinerParent });
			}
		}
	}

	private void NavisSelection_Changed(object sender, EventArgs e)
	{
		if (!_IsResolvingTaskSelection)
		{
			TryRefreshData();
		}
		SetSelectionBtn.Enabled = ((!Application.ActiveDocument.CurrentSelection.IsEmpty && SelectedTask != null) ? true : false);
	}

	private void TryRefreshData()
	{
		try
		{
			SelectedTask = null;
			_Tasks.Clear();
			List<TimelinerTask> list = new List<TimelinerTask>();
			DocumentCurrentSelection currentSelection = Application.ActiveDocument.CurrentSelection;
			if (currentSelection.IsEmpty)
			{
				ObjectTb.Text = "<No Selection>";
				return;
			}
			ModelItem val = currentSelection.SelectedItems[0];
			PropertyCategory val2 = val.PropertyCategories.FindCategoryByDisplayName("TimeLiner");
			if (val2 != null)
			{
				int num = 1;
				DateTime? startDate = default(DateTime?);
				DateTime? endDate = default(DateTime?);
				for (DataProperty val3 = val2.Properties.FindPropertyByDisplayName($"Contained in Task:{num}"); val3 != null; val3 = val2.Properties.FindPropertyByDisplayName($"Contained in Task:{num}"))
				{
					DataPropertyCollection properties = val2.Properties;
					DataProperty val4 = properties.FindPropertyByDisplayName($"Contained in Task Start (Planned):{num}");
					if (val4 != null)
					{
						startDate = val4.Value.ToDateTime();
					}
					DataProperty val5 = properties.FindPropertyByDisplayName($"Contained in Task End (Planned):{num}");
					if (val5 != null)
					{
						endDate = val5.Value.ToDateTime();
					}
					TimelinerTask val6 = FindTaskMatch(val3.Value.ToDisplayString(), startDate, endDate);
					if (val6 != null)
					{
						list.Add(val6);
					}
					properties = null;
					num = checked(num + 1);
				}
			}
			if (list.Count > 0)
			{
				_Tasks = list.OrderBy([SpecialName] (TimelinerTask t) => t.PlannedStartDate).ToList();
				SelectedTask = _Tasks.First();
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(Application.Gui.MainWindow, ex2.Message, "Timeliner Assistant Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private TimelinerTask FindTaskMatch(string TaskName, DateTime? StartDate, DateTime? EndDate)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Expected O, but got Unknown
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Expected O, but got Unknown
		try
		{
			DocumentTimeliner val = (DocumentTimeliner)Application.ActiveDocument.Timeliner;
			foreach (TimelinerTask child in val.TasksRoot.Children)
			{
				TimelinerTask checkTask = child;
				TimelinerTask val2 = CheckMatchAttributes(checkTask, StartDate, EndDate, TaskName);
				if (val2 != null)
				{
					ArrayList arrayList = new ArrayList();
					arrayList.Add("");
					ArrayList arrayList2 = arrayList;
					arrayList2.AddRange((from st in ((IEnumerable<SavedItem>)val.SimulationTaskTypes).Select((Func<SavedItem, SimulationTaskType>)([SpecialName] (SavedItem st) => (SimulationTaskType)st))
						select ((SavedItem)st).DisplayName).ToArray());
					SimulationTaskTypeCb.SelectedIndexChanged -= SimulationTaskTypeCb_SelectedIndexChanged;
					SimulationTaskTypeCb.DataSource = arrayList2;
					SimulationTaskTypeCb.SelectedIndexChanged += SimulationTaskTypeCb_SelectedIndexChanged;
					return val2;
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(Application.Gui.MainWindow, ex2.Message, "Timeliner Assistant Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
		return null;
	}

	private TimelinerTask CheckMatchAttributes(TimelinerTask CheckTask, DateTime? TaskStart, DateTime? TaskEnd, string TaskName)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Expected O, but got Unknown
		if (Extensions.IncludesRange(CheckTask, TaskStart, TaskEnd))
		{
			if (Extensions.IsSameTask(CheckTask, TaskStart, TaskEnd, TaskName))
			{
				return CheckTask;
			}
			TimelinerTask val = null;
			foreach (TimelinerTask child in ((GroupItem)CheckTask).Children)
			{
				TimelinerTask checkTask = child;
				val = CheckMatchAttributes(checkTask, TaskStart, TaskEnd, TaskName);
				if (val != null)
				{
					return val;
				}
			}
		}
		return null;
	}

	private void ChangeTaskType(TimelinerTask Task, string NewTypeName)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected O, but got Unknown
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Expected O, but got Unknown
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Expected O, but got Unknown
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Expected O, but got Unknown
		DocumentTimeliner val = (DocumentTimeliner)Application.ActiveDocument.Timeliner;
		int[] path = CalculateTaskIndexPath(val, Task);
		GroupItem val2 = (GroupItem)((SavedItem)val.TasksRoot).CreateCopy();
		TimelinerTask val3 = (TimelinerTask)ResolveTaskIndexPath(val2, path);
		val3.SimulationTaskTypeName = NewTypeName;
		val.TasksCopyFrom(val2.Children);
		SelectedTask = (TimelinerTask)ResolveTaskIndexPath(val.TasksRoot, path);
	}

	private void SetTaskSelection(TimelinerTask Task, IEnumerable<ModelItem> items)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected O, but got Unknown
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Expected O, but got Unknown
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Expected O, but got Unknown
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Expected O, but got Unknown
		DocumentTimeliner val = (DocumentTimeliner)Application.ActiveDocument.Timeliner;
		int[] path = CalculateTaskIndexPath(val, Task);
		GroupItem val2 = (GroupItem)((SavedItem)val.TasksRoot).CreateCopy();
		TimelinerTask val3 = (TimelinerTask)ResolveTaskIndexPath(val2, path);
		val3.Selection.CopyFrom(items);
		val.TasksCopyFrom(val2.Children);
		SelectedTask = (TimelinerTask)ResolveTaskIndexPath(val.TasksRoot, path);
	}

	private void PreviousTaskLbl_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		try
		{
			int num = _Tasks.IndexOf(SelectedTask);
			if (num > 0)
			{
				SelectedTask = _Tasks[checked(num - 1)];
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(Application.Gui.MainWindow, "Task navigation failed.\r\n" + ex2.Message, "Timeliner Assistant Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void NextTaskLbl_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		checked
		{
			try
			{
				int num = _Tasks.IndexOf(SelectedTask);
				if (num < _Tasks.Count - 1)
				{
					SelectedTask = _Tasks[num + 1];
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(Application.Gui.MainWindow, "Task navigation failed.\r\n" + ex2.Message, "Timeliner Assistant Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}
	}

	private void FormatDates(string NewFormat)
	{
		try
		{
			if (SelectedTask.PlannedStartDate.HasValue)
			{
				StartTb.Text = SelectedTask.PlannedStartDate.Value.ToString(NewFormat);
			}
			else
			{
				StartTb.Text = "<Not Defined>";
			}
			if (SelectedTask.PlannedEndDate.HasValue)
			{
				EndTb.Text = SelectedTask.PlannedEndDate.Value.ToString(NewFormat);
			}
			else
			{
				EndTb.Text = "<Not Defined>";
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show("The dates formating with: " + NewFormat + " failed." + Environment.NewLine + ex2.Message, "Timeliner Assistant Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private SavedItem ResolveTaskIndexPath(GroupItem g, int[] Path)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected O, but got Unknown
		foreach (int num in Path)
		{
			g = (GroupItem)g.Children[num];
		}
		return (SavedItem)(object)g;
	}

	private int[] CalculateTaskIndexPath(DocumentTimeliner dtl, TimelinerTask task)
	{
		ArrayList arrayList = new ArrayList();
		SavedItem val = (SavedItem)(object)task;
		do
		{
			arrayList.Add(val.Parent.Children.IndexOf(val));
			val = (SavedItem)(object)val.Parent;
		}
		while (!((NativeHandle)(object)val == (NativeHandle)(object)dtl.TasksRoot));
		arrayList.Reverse();
		return (int[])arrayList.ToArray(typeof(int));
	}

	private ModelItem GetTimelinerParent(ModelItem mi)
	{
		ModelItem result;
		try
		{
			for (DataProperty val = mi.PropertyCategories.FindPropertyByDisplayName("TimeLiner", "Attached to Task:1"); val == null; val = mi.PropertyCategories.FindPropertyByDisplayName("TimeLiner", "Attached to Task:1"))
			{
				mi = mi.Parent;
			}
			result = mi;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show("Parent could not be retrieved." + Environment.NewLine + ex2.Message, "Timeliner Assistant Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			result = null;
			ProjectData.ClearProjectError();
		}
		return result;
	}
}
