using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[DesignerGenerated]
public class ErrorLogUF : Form
{
	private IContainer components;

	[AccessedThroughProperty("Label1")]
	private Label _Label1;

	[AccessedThroughProperty("ErrorTb")]
	private RichTextBox _ErrorTb;

	[AccessedThroughProperty("NoBtn")]
	private Button _NoBtn;

	[AccessedThroughProperty("YesBtn")]
	private Button _YesBtn;

	internal virtual Label Label1
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label1 = value;
		}
	}

	internal virtual RichTextBox ErrorTb
	{
		[DebuggerNonUserCode]
		get
		{
			return _ErrorTb;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_ErrorTb = value;
		}
	}

	internal virtual Button NoBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _NoBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_NoBtn = value;
		}
	}

	internal virtual Button YesBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _YesBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_YesBtn = value;
		}
	}

	[DebuggerNonUserCode]
	public ErrorLogUF()
	{
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.Label1 = new System.Windows.Forms.Label();
		this.ErrorTb = new System.Windows.Forms.RichTextBox();
		this.NoBtn = new System.Windows.Forms.Button();
		this.YesBtn = new System.Windows.Forms.Button();
		this.SuspendLayout();
		this.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		System.Windows.Forms.Label label = this.Label1;
		System.Drawing.Point location = new System.Drawing.Point(10, 13);
		label.Location = location;
		this.Label1.Name = "Label1";
		System.Windows.Forms.Label label2 = this.Label1;
		System.Drawing.Size size = new System.Drawing.Size(426, 33);
		label2.Size = size;
		this.Label1.TabIndex = 0;
		this.Label1.Text = "The following warnings have been raised while transfering data to the Timeliner. Do you want the Timeliner to be updated with the valid data anyway?";
		this.ErrorTb.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		System.Windows.Forms.RichTextBox errorTb = this.ErrorTb;
		location = new System.Drawing.Point(10, 50);
		errorTb.Location = location;
		this.ErrorTb.Name = "ErrorTb";
		System.Windows.Forms.RichTextBox errorTb2 = this.ErrorTb;
		size = new System.Drawing.Size(426, 148);
		errorTb2.Size = size;
		this.ErrorTb.TabIndex = 1;
		this.ErrorTb.Text = "";
		this.NoBtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.NoBtn.DialogResult = System.Windows.Forms.DialogResult.No;
		System.Windows.Forms.Button noBtn = this.NoBtn;
		location = new System.Drawing.Point(280, 205);
		noBtn.Location = location;
		this.NoBtn.Name = "NoBtn";
		System.Windows.Forms.Button noBtn2 = this.NoBtn;
		size = new System.Drawing.Size(75, 23);
		noBtn2.Size = size;
		this.NoBtn.TabIndex = 2;
		this.NoBtn.Text = "No";
		this.NoBtn.UseVisualStyleBackColor = true;
		this.YesBtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.YesBtn.DialogResult = System.Windows.Forms.DialogResult.Yes;
		System.Windows.Forms.Button yesBtn = this.YesBtn;
		location = new System.Drawing.Point(361, 205);
		yesBtn.Location = location;
		this.YesBtn.Name = "YesBtn";
		System.Windows.Forms.Button yesBtn2 = this.YesBtn;
		size = new System.Drawing.Size(75, 23);
		yesBtn2.Size = size;
		this.YesBtn.TabIndex = 2;
		this.YesBtn.Text = "Yes";
		this.YesBtn.UseVisualStyleBackColor = true;
		System.Drawing.SizeF sizeF = new System.Drawing.SizeF(6f, 13f);
		this.AutoScaleDimensions = sizeF;
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		size = new System.Drawing.Size(445, 239);
		this.ClientSize = size;
		this.Controls.Add(this.YesBtn);
		this.Controls.Add(this.NoBtn);
		this.Controls.Add(this.ErrorTb);
		this.Controls.Add(this.Label1);
		this.Font = new System.Drawing.Font("Segoe UI", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.MaximizeBox = false;
		this.MinimizeBox = false;
		size = new System.Drawing.Size(400, 210);
		this.MinimumSize = size;
		this.Name = "ErrorLogUF";
		this.ShowIcon = false;
		this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Transfer Errors";
		this.ResumeLayout(false);
	}
}
