using System;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Plugins;
using Autodesk.Navisworks.Api.Timeliner;
using Microsoft.VisualBasic.CompilerServices;
using NWTimelinerUtils.My;

namespace NWTimelinerUtils;

[Plugin("NWTimelinerUtils.TimelinerSearchSetsAddin", "LORG", DisplayName = "Timeliner\r\nSearch Sets", ToolTip = "Create search sets for timeliner based on tasks fields")]
[AddInPlugin(/*Could not decode attribute arguments.*/)]
public class TimelinerSearchSetsAddin : AddInPlugin
{
	public const string PLUGIN_NAME = "NWTimelinerUtils.TimelinerSearchSetsAddin";

	public const string PLUGIN_DEV_ID = "LORG";

	public const string PLUGIN_DISPLAY_NAME = "Timeliner\r\nSearch Sets";

	public const string PLUGIN_ID = "NWTimelinerUtils.TimelinerSearchSetsAddin.LORG";

	private const string _AUTHENTICATOR_ADDIN_ID = "NWAuthenticator.AuthenticatorAddin.LORG";

	private const string _PLUGIN_DISPLAY_NAME = "Timeliner Search Sets";

	private static TimelinerSearchSetBuilder Config = new TimelinerSearchSetBuilder();

	[DebuggerNonUserCode]
	public TimelinerSearchSetsAddin()
	{
	}

	public override int Execute(params string[] parameters)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Expected O, but got Unknown
		int result;
		try
		{
			AddInPluginRecord val = (AddInPluginRecord)Application.Plugins.FindPlugin("NWAuthenticator.AuthenticatorAddin.LORG");
			string[] array = new string[2]
			{
				Conversions.ToString(-1),
				Conversions.ToString(23)
			};
			if (val == null)
			{
				result = NotifyUnlicensed();
			}
			else
			{
				int num = val.Execute(array);
				int num2 = Cipher.EncryptTime();
				if (num2 != num)
				{
					result = NotifyUnlicensed();
				}
				else
				{
					try
					{
						Config.LoadXmlString(MySettingsProperty.Settings.TLSETS_CONFIG);
					}
					catch (Exception projectError)
					{
						ProjectData.SetProjectError(projectError);
						ProjectData.ClearProjectError();
					}
					using (SearchSetsOptionsUF searchSetsOptionsUF = new SearchSetsOptionsUF(Config))
					{
						searchSetsOptionsUF.ShowDialog();
					}
					MySettingsProperty.Settings.TLSETS_CONFIG = Config.ToXmlString();
					MySettingsProperty.Settings.Save();
					result = -1;
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show("Error occurred when loading addin addin: Timeliner Search Sets:\r\n" + ex2.Message, "Addin error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			result = -2;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	private int NotifyUnlicensed()
	{
		MessageBox.Show(Application.Gui.MainWindow, "No valid licence found", "Licence missing", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		return 0;
	}

	public override CommandState CanExecute()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		CommandState val = ((AddInPlugin)this).CanExecute();
		if (Application.ActiveDocument == null || ((DocumentTimeliner)Application.ActiveDocument.Timeliner).TasksRoot.Children.Count == 0)
		{
			val.IsEnabled = false;
		}
		return val;
	}

	public override bool TryShowHelp()
	{
		bool result;
		try
		{
			Help.ShowHelp(null, "http://de-software.web/Plugins/Navisworks/Timeliner Utilities/Help/Timeliner Utilities.html#Timeliner Sets");
			result = true;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}
}
