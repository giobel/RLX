using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Xml;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

public class SearchFieldMapping : XmlSerializable, INotifyPropertyChanged
{
	private bool _Use;

	private string _FieldName;

	private string _CategoryName;

	private string _PropertyName;

	private MappingMode _Mode;

	public static string[] TaskSearchFields = new string[15]
	{
		"User1", "User2", "User3", "User4", "User5", "User6", "User7", "User8", "User9", "User10",
		"SimulationTaskTypeName", "DisplayId", "DisplayName", "Guid", "SynchronizationId"
	};

	public const string XML_ROOT_NAME = "SearchFieldMapping";

	public const string XML_MAP_USE = "Use";

	public const string XML_MAP_FIELD_NAME = "FieldName";

	public const string XML_MAP_CAT_NAME = "CategoryName";

	public const string XML_MAP_PROP_NAME = "PropertyName";

	public const string XML_MAP_MODE = "Mode";

	public bool Use
	{
		get
		{
			return _Use;
		}
		set
		{
			SetProperty(ref _Use, value, "Use");
		}
	}

	public string FieldName => _FieldName;

	public string CategoryName
	{
		get
		{
			return _CategoryName;
		}
		set
		{
			SetProperty(ref _CategoryName, value, "CategoryName");
		}
	}

	public string PropertyName
	{
		get
		{
			return _PropertyName;
		}
		set
		{
			SetProperty(ref _PropertyName, value, "PropertyName");
		}
	}

	public MappingMode Mode
	{
		get
		{
			return _Mode;
		}
		set
		{
			SetProperty(ref _Mode, value, "Mode");
		}
	}

	public override string XML_ROOT => "SearchFieldMapping";

	[method: DebuggerNonUserCode]
	public event PropertyChangedEventHandler PropertyChanged;

	protected bool SetProperty<T>(ref T storage, T value, [CallerMemberName] string PropertyName = null)
	{
		if (object.Equals(storage, value))
		{
			return false;
		}
		storage = value;
		OnPropertyChanged(PropertyName);
		return true;
	}

	protected virtual void OnPropertyChanged([CallerMemberName] string PropertyName = null)
	{
		PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
	}

	public SearchFieldMapping(string field)
	{
		_Use = false;
		_Mode = MappingMode.Equals;
		_FieldName = field;
	}

	public SearchFieldMapping(string field, string categoryName, string propertyName)
	{
		_Use = false;
		_Mode = MappingMode.Equals;
		_FieldName = field;
		_CategoryName = categoryName;
	}

	private void SetFieldName(string value)
	{
		SetProperty(ref _FieldName, value, "FieldName");
	}

	public static BindingList<SearchFieldMapping> GetFields()
	{
		BindingList<SearchFieldMapping> bindingList = new BindingList<SearchFieldMapping>();
		string[] taskSearchFields = TaskSearchFields;
		foreach (string field in taskSearchFields)
		{
			bindingList.Add(new SearchFieldMapping(field));
		}
		return bindingList;
	}

	public override XmlElement ToXmlNamedElement(XmlDocumentEx xmlDoc, string rootName)
	{
		XmlElement xmlElement = xmlDoc.CreateElement(rootName);
		xmlElement.SetAttribute("Use", Use.ToString());
		xmlElement.SetAttribute("FieldName", FieldName);
		xmlElement.SetAttribute("CategoryName", CategoryName);
		xmlElement.SetAttribute("PropertyName", PropertyName);
		xmlElement.SetAttribute("Mode", Mode.ToString());
		return xmlElement;
	}

	public override void LoadXmlElement(XmlElement Elt)
	{
		foreach (XmlAttribute attribute in Elt.Attributes)
		{
			switch (attribute.Name)
			{
			case "Use":
				Use = bool.Parse(attribute.Value);
				break;
			case "FieldName":
				SetFieldName(attribute.Value);
				break;
			case "CategoryName":
				CategoryName = attribute.Value;
				break;
			case "PropertyName":
				PropertyName = attribute.Value;
				break;
			case "Mode":
				Mode = (MappingMode)Conversions.ToInteger(Enum.Parse(typeof(MappingMode), attribute.Value));
				break;
			}
		}
	}
}
