using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using System.Xml;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Timeliner;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[DesignerGenerated]
public class IOForm : Form
{
	[CompilerGenerated]
	internal class _Closure_0024__1
	{
		public string _0024VB_0024Local_NodeName;

		[DebuggerNonUserCode]
		public _Closure_0024__1(_Closure_0024__1 other)
		{
			if (other != null)
			{
				_0024VB_0024Local_NodeName = other._0024VB_0024Local_NodeName;
			}
		}
	}

	[CompilerGenerated]
	internal class _Closure_0024__2
	{
		public XmlElement _0024VB_0024Local_Elt;

		[DebuggerNonUserCode]
		public _Closure_0024__2(_Closure_0024__2 other)
		{
			if (other != null)
			{
				_0024VB_0024Local_Elt = other._0024VB_0024Local_Elt;
			}
		}
	}

	private IContainer components;

	[AccessedThroughProperty("ImportBtn")]
	private Button _ImportBtn;

	[AccessedThroughProperty("ExportBtn")]
	private Button _ExportBtn;

	private const string X_APPEARANCES = "Appearances";

	private const string X_APPEARANCE = "Appearance";

	private const string X_DISP_NAME = "DisplayName";

	private const string X_COLOR = "Color";

	private const string X_TRANSPARENCY = "Transparency";

	private const string X_SIM_TASK_TYPES = "SimulationTaskTypes";

	private const string X_SIM_TASK_TYPE = "SimulationTaskType";

	private const string X_SIM_START = "SimulationStartStatus";

	private const string X_START = "StartStatus";

	private const string X_END = "EndStatus";

	private const string X_UNDERRUN = "UnderrunStatus";

	private const string X_OVERRUN = "OverrunStatus";

	private const string X_APP_MODE = "AppearanceMode";

	private const string X_SIM_APP_NAME = "SimulationAppearanceName";

	internal virtual Button ImportBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _ImportBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = ImportBtn_Click;
			if (_ImportBtn != null)
			{
				_ImportBtn.Click -= value2;
			}
			_ImportBtn = value;
			if (_ImportBtn != null)
			{
				_ImportBtn.Click += value2;
			}
		}
	}

	internal virtual Button ExportBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _ExportBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = ExportBtn_Click;
			if (_ExportBtn != null)
			{
				_ExportBtn.Click -= value2;
			}
			_ExportBtn = value;
			if (_ExportBtn != null)
			{
				_ExportBtn.Click += value2;
			}
		}
	}

	[DebuggerNonUserCode]
	public IOForm()
	{
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.ImportBtn = new System.Windows.Forms.Button();
		this.ExportBtn = new System.Windows.Forms.Button();
		this.SuspendLayout();
		this.ImportBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
		System.Windows.Forms.Button importBtn = this.ImportBtn;
		System.Drawing.Point location = new System.Drawing.Point(30, 18);
		importBtn.Location = location;
		this.ImportBtn.Name = "ImportBtn";
		System.Windows.Forms.Button importBtn2 = this.ImportBtn;
		System.Drawing.Size size = new System.Drawing.Size(75, 23);
		importBtn2.Size = size;
		this.ImportBtn.TabIndex = 0;
		this.ImportBtn.Text = "&Import";
		this.ImportBtn.UseVisualStyleBackColor = true;
		this.ExportBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
		System.Windows.Forms.Button exportBtn = this.ExportBtn;
		location = new System.Drawing.Point(111, 18);
		exportBtn.Location = location;
		this.ExportBtn.Name = "ExportBtn";
		System.Windows.Forms.Button exportBtn2 = this.ExportBtn;
		size = new System.Drawing.Size(75, 23);
		exportBtn2.Size = size;
		this.ExportBtn.TabIndex = 0;
		this.ExportBtn.Text = "&Export";
		this.ExportBtn.UseVisualStyleBackColor = true;
		System.Drawing.SizeF sizeF = new System.Drawing.SizeF(6f, 13f);
		this.AutoScaleDimensions = sizeF;
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.SystemColors.Window;
		size = new System.Drawing.Size(216, 59);
		this.ClientSize = size;
		this.Controls.Add(this.ExportBtn);
		this.Controls.Add(this.ImportBtn);
		this.Font = new System.Drawing.Font("Segoe UI", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
		this.MaximizeBox = false;
		this.MinimizeBox = false;
		this.Name = "IOForm";
		this.ShowIcon = false;
		this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Timeliner Appearances Manager";
		this.ResumeLayout(false);
	}

	private void ImportBtn_Click(object sender, EventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.CheckFileExists = true;
		openFileDialog.Filter = "Xml Files|*.xml";
		OpenFileDialog openFileDialog2 = openFileDialog;
		if (openFileDialog2.ShowDialog() == DialogResult.OK)
		{
			LoadAppearancesFromXml(openFileDialog2.FileName);
		}
	}

	private void ExportBtn_Click(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		saveFileDialog.Filter = "Xml Files|*.xml";
		saveFileDialog.FileName = "TimeLiner Configuration " + Strings.Replace(Strings.Replace(DateAndTime.Now.ToString(), "/", "-"), ":", "-");
		SaveFileDialog saveFileDialog2 = saveFileDialog;
		if (saveFileDialog2.ShowDialog() == DialogResult.OK)
		{
			SaveAppearancesToXml(saveFileDialog2.FileName);
		}
	}

	public void LoadAppearancesFromXml(string XmlFilePath)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Expected O, but got Unknown
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Expected O, but got Unknown
		//IL_0388: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Expected O, but got Unknown
		Document activeDocument = Application.ActiveDocument;
		DocumentTimeliner val = (DocumentTimeliner)activeDocument.Timeliner;
		XmlDocumentEx xmlDocumentEx = new XmlDocumentEx();
		xmlDocumentEx.Load(XmlFilePath);
		XmlNodeList elementsByTagName = xmlDocumentEx.GetElementsByTagName("Appearance");
		bool flag = false;
		if (elementsByTagName.Count > 0)
		{
			List<SavedItem> list = new List<SavedItem>();
			if (val.SimulationAppearances.Count > 0)
			{
				ConfirmationUF confirmationUF = new ConfirmationUF();
				switch (confirmationUF.ShowDialog(Application.Gui.MainWindow, "There are existing Appearances in the TimeLiner, do you want to keep, merge or replace them?", "Timeliner Configuration Manager"))
				{
				case DialogResult.Cancel:
					return;
				case DialogResult.Yes:
					flag = true;
					foreach (SavedItem simulationAppearance in val.SimulationAppearances)
					{
						list.Add(simulationAppearance.CreateCopy());
					}
					break;
				case DialogResult.OK:
					flag = false;
					break;
				case DialogResult.Ignore:
					goto IL_0233;
				}
			}
			{
				IEnumerator enumerator2 = elementsByTagName.GetEnumerator();
				try
				{
					_Closure_0024__1 closure_0024__ = default(_Closure_0024__1);
					while (enumerator2.MoveNext())
					{
						closure_0024__ = new _Closure_0024__1(closure_0024__);
						XmlElement xmlElement = (XmlElement)enumerator2.Current;
						closure_0024__._0024VB_0024Local_NodeName = xmlElement.GetAttribute("DisplayName");
						Color val2 = AdskColor((XmlElement)xmlElement.GetElementsByTagName("Color")[0]);
						double num = double.Parse(xmlElement.GetElementsByTagName("Transparency")[0].InnerText);
						bool flag2 = !flag;
						if (flag)
						{
							IEnumerable<SimulationAppearance> source = (from sa in ((IEnumerable<SavedItem>)list).Select((Func<SavedItem, SimulationAppearance>)([SpecialName] (SavedItem sa) => (SimulationAppearance)sa))
								select (sa)).Where(closure_0024__._Lambda_0024__6);
							if (source.Count() > 0)
							{
								source.ElementAtOrDefault(0).Color = val2;
								source.ElementAtOrDefault(0).Transparency = num;
							}
							else
							{
								flag2 = true;
							}
						}
						if (flag2)
						{
							list.Add((SavedItem)new SimulationAppearance(closure_0024__._0024VB_0024Local_NodeName, val2, num));
						}
					}
				}
				finally
				{
					IDisposable disposable = enumerator2 as IDisposable;
					if (disposable != null)
					{
						disposable.Dispose();
					}
				}
			}
			val.SimulationAppearancesCopyFrom((IEnumerable<SavedItem>)list);
		}
		goto IL_0233;
		IL_0233:
		XmlNodeList elementsByTagName2 = xmlDocumentEx.GetElementsByTagName("SimulationTaskType");
		flag = false;
		if (elementsByTagName2.Count <= 0)
		{
			return;
		}
		List<SavedItem> list2 = new List<SavedItem>();
		if (val.SimulationTaskTypes.Count > 0)
		{
			ConfirmationUF confirmationUF2 = new ConfirmationUF();
			switch (confirmationUF2.ShowDialog(Application.Gui.MainWindow, "There are existing SimulationTaskTypes in the TimeLiner, do you want to keep, merge or replace them?", "Timeliner Configuration Manager"))
			{
			case DialogResult.Cancel:
			case DialogResult.Ignore:
				return;
			case DialogResult.Yes:
				flag = true;
				foreach (SavedItem simulationTaskType in val.SimulationTaskTypes)
				{
					list2.Add(simulationTaskType.CreateCopy());
				}
				break;
			case DialogResult.OK:
				flag = false;
				break;
			}
		}
		IEnumerator enumerator4 = elementsByTagName2.GetEnumerator();
		try
		{
			_Closure_0024__2 closure_0024__2 = default(_Closure_0024__2);
			while (enumerator4.MoveNext())
			{
				closure_0024__2 = new _Closure_0024__2(closure_0024__2);
				closure_0024__2._0024VB_0024Local_Elt = (XmlElement)enumerator4.Current;
				SimulationTaskType val3 = null;
				IEnumerable<SimulationTaskType> source2 = (from stt in ((IEnumerable<SavedItem>)list2).Select((Func<SavedItem, SimulationTaskType>)([SpecialName] (SavedItem stt) => (SimulationTaskType)stt))
					select (stt)).Where(closure_0024__2._Lambda_0024__9);
				if (flag && source2.Count() > 0)
				{
					val3 = source2.ElementAtOrDefault(0);
				}
				else
				{
					SimulationTaskType val4 = new SimulationTaskType();
					((SavedItem)val4).DisplayName = closure_0024__2._0024VB_0024Local_Elt.GetAttribute("DisplayName");
					val3 = val4;
					list2.Add((SavedItem)(object)val3);
				}
				val3.SimulationStartStatus = SimulationStatus((XmlElement)closure_0024__2._0024VB_0024Local_Elt.GetElementsByTagName("SimulationStartStatus")[0]);
				val3.StartStatus = SimulationStatus((XmlElement)closure_0024__2._0024VB_0024Local_Elt.GetElementsByTagName("StartStatus")[0]);
				val3.EndStatus = SimulationStatus((XmlElement)closure_0024__2._0024VB_0024Local_Elt.GetElementsByTagName("EndStatus")[0]);
				val3.UnderrunStatus = SimulationStatus((XmlElement)closure_0024__2._0024VB_0024Local_Elt.GetElementsByTagName("UnderrunStatus")[0]);
				val3.OverrunStatus = SimulationStatus((XmlElement)closure_0024__2._0024VB_0024Local_Elt.GetElementsByTagName("OverrunStatus")[0]);
			}
		}
		finally
		{
			IDisposable disposable2 = enumerator4 as IDisposable;
			if (disposable2 != null)
			{
				disposable2.Dispose();
			}
		}
		val.SimulationTaskTypesCopyFrom((IEnumerable<SavedItem>)list2);
	}

	public void SaveAppearancesToXml(string XmlFilePath)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Expected O, but got Unknown
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Expected O, but got Unknown
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Expected O, but got Unknown
		Document activeDocument = Application.ActiveDocument;
		DocumentTimeliner val = (DocumentTimeliner)activeDocument.Timeliner;
		if (val.SimulationAppearances.Count == 0 && val.SimulationTaskTypes.Count == 0)
		{
			MessageBox.Show(Application.Gui.MainWindow, "No Appearances or Task Type found to export.", "Timeliner Configuration Manager", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			return;
		}
		XmlDocumentEx xmlDocumentEx = new XmlDocumentEx();
		XmlElement xmlElement = xmlDocumentEx.CreateElement("TimeLinerConfiguration");
		xmlElement.AppendChild(xmlDocumentEx.CreateComment("LOR+ Navisworks Xml TimeLiner Configuration Export"));
		XmlElement xmlElement2 = xmlDocumentEx.CreateElement("Appearances");
		xmlElement2.AppendChild(xmlDocumentEx.CreateComment("Navisworks Colors are coded RGB (no Alpha) with double values from 0 to 1 transparency is a separate attribute coded with a double bewteen 0 and 1 as well. "));
		foreach (SimulationAppearance simulationAppearance in val.SimulationAppearances)
		{
			SimulationAppearance val2 = simulationAppearance;
			XmlElement xmlElement3 = xmlDocumentEx.CreateElement("Appearance", "DisplayName", ((SavedItem)val2).DisplayName);
			xmlElement3.AppendChild((XmlNode)xmlDocumentEx.CreateColorElement("Color", val2.Color));
			xmlElement3.AppendChild(xmlDocumentEx.CreateElement("Transparency", Conversions.ToString(val2.Transparency)));
			xmlElement2.AppendChild(xmlElement3);
		}
		XmlElement xmlElement4 = xmlDocumentEx.CreateElement("SimulationTaskTypes");
		xmlElement4.AppendChild(xmlDocumentEx.CreateComment("SimulationTaskType Statuses displayed to the user are mapped to a system enum as follow: None=None, Model Appearance=Default, Hide=Hidden, User Named=UserAppearance (+ Appearance Name)"));
		foreach (SimulationTaskType simulationTaskType in val.SimulationTaskTypes)
		{
			SimulationTaskType val3 = simulationTaskType;
			XmlElement xmlElement5 = xmlDocumentEx.CreateElement("SimulationTaskType", "DisplayName", ((SavedItem)val3).DisplayName);
			xmlElement5.AppendChild(SimulationStatus(xmlDocumentEx, val3.SimulationStartStatus, "SimulationStartStatus"));
			xmlElement5.AppendChild(SimulationStatus(xmlDocumentEx, val3.StartStatus, "StartStatus"));
			xmlElement5.AppendChild(SimulationStatus(xmlDocumentEx, val3.EndStatus, "EndStatus"));
			xmlElement5.AppendChild(SimulationStatus(xmlDocumentEx, val3.UnderrunStatus, "UnderrunStatus"));
			xmlElement5.AppendChild(SimulationStatus(xmlDocumentEx, val3.OverrunStatus, "OverrunStatus"));
			xmlElement4.AppendChild(xmlElement5);
		}
		xmlElement.AppendChild(xmlElement2);
		xmlElement.AppendChild(xmlElement4);
		xmlDocumentEx.AppendChild(xmlElement);
		Directory.CreateDirectory(Path.GetDirectoryName(XmlFilePath));
		xmlDocumentEx.Save(XmlFilePath);
	}

	private XmlElement SimulationStatus(XmlDocumentEx Doc, SimulationStatus status, string Name)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Invalid comparison between Unknown and I4
		XmlElement xmlElement = Doc.CreateElement(Name);
		xmlElement.SetAttribute("AppearanceMode", ((Enum)status.AppearanceMode).ToString());
		if ((int)status.AppearanceMode == 3)
		{
			xmlElement.SetAttribute("SimulationAppearanceName", status.SimulationAppearanceName);
		}
		return xmlElement;
	}

	private Color AdskColor(XmlElement elt)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Expected O, but got Unknown
		return new Color(Conversions.ToDouble(elt.GetAttribute("red")), Conversions.ToDouble(elt.GetAttribute("green")), Conversions.ToDouble(elt.GetAttribute("blue")));
	}

	private SimulationStatus SimulationStatus(XmlElement elt)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected O, but got Unknown
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Invalid comparison between Unknown and I4
		SimulationStatus val = new SimulationStatus();
		val.AppearanceMode = (SimulationAppearanceMode)Conversions.ToInteger(Enum.Parse(typeof(SimulationAppearanceMode), elt.GetAttribute("AppearanceMode")));
		if ((int)val.AppearanceMode == 3)
		{
			val.SimulationAppearanceName = elt.GetAttribute("SimulationAppearanceName");
		}
		return val;
	}
}
