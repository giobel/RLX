using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[DesignerGenerated]
public class ConfirmationUF : Form
{
	private IContainer components;

	[AccessedThroughProperty("SplitContainer1")]
	private SplitContainer _SplitContainer1;

	[AccessedThroughProperty("MergeBtn")]
	private Button _MergeBtn;

	[AccessedThroughProperty("ReplaceBtn")]
	private Button _ReplaceBtn;

	[AccessedThroughProperty("SkipBtn")]
	private Button _SkipBtn;

	[AccessedThroughProperty("MainTT")]
	private ToolTip _MainTT;

	[AccessedThroughProperty("CancelBtn")]
	private Button _CancelBtn;

	[AccessedThroughProperty("MessageRtb")]
	private RichTextBox _MessageRtb;

	[AccessedThroughProperty("FlowLayoutPanel1")]
	private FlowLayoutPanel _FlowLayoutPanel1;

	internal virtual SplitContainer SplitContainer1
	{
		[DebuggerNonUserCode]
		get
		{
			return _SplitContainer1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_SplitContainer1 = value;
		}
	}

	internal virtual Button MergeBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _MergeBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_MergeBtn = value;
		}
	}

	internal virtual Button ReplaceBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _ReplaceBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_ReplaceBtn = value;
		}
	}

	internal virtual Button SkipBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _SkipBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_SkipBtn = value;
		}
	}

	internal virtual ToolTip MainTT
	{
		[DebuggerNonUserCode]
		get
		{
			return _MainTT;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_MainTT = value;
		}
	}

	internal virtual Button CancelBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _CancelBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_CancelBtn = value;
		}
	}

	internal virtual RichTextBox MessageRtb
	{
		[DebuggerNonUserCode]
		get
		{
			return _MessageRtb;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_MessageRtb = value;
		}
	}

	internal virtual FlowLayoutPanel FlowLayoutPanel1
	{
		[DebuggerNonUserCode]
		get
		{
			return _FlowLayoutPanel1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_FlowLayoutPanel1 = value;
		}
	}

	public string Message
	{
		get
		{
			return MessageRtb.Text;
		}
		set
		{
			MessageRtb.Text = value;
		}
	}

	[DebuggerNonUserCode]
	public ConfirmationUF()
	{
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		this.SplitContainer1 = new System.Windows.Forms.SplitContainer();
		this.MessageRtb = new System.Windows.Forms.RichTextBox();
		this.MergeBtn = new System.Windows.Forms.Button();
		this.ReplaceBtn = new System.Windows.Forms.Button();
		this.SkipBtn = new System.Windows.Forms.Button();
		this.CancelBtn = new System.Windows.Forms.Button();
		this.MainTT = new System.Windows.Forms.ToolTip(this.components);
		this.FlowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
		((System.ComponentModel.ISupportInitialize)this.SplitContainer1).BeginInit();
		this.SplitContainer1.Panel1.SuspendLayout();
		this.SplitContainer1.Panel2.SuspendLayout();
		this.SplitContainer1.SuspendLayout();
		this.FlowLayoutPanel1.SuspendLayout();
		this.SuspendLayout();
		this.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
		this.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
		System.Windows.Forms.SplitContainer splitContainer = this.SplitContainer1;
		System.Drawing.Point location = new System.Drawing.Point(0, 0);
		splitContainer.Location = location;
		this.SplitContainer1.Name = "SplitContainer1";
		this.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
		this.SplitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Window;
		this.SplitContainer1.Panel1.Controls.Add(this.MessageRtb);
		this.SplitContainer1.Panel2.Controls.Add(this.FlowLayoutPanel1);
		System.Windows.Forms.SplitContainer splitContainer2 = this.SplitContainer1;
		System.Drawing.Size size = new System.Drawing.Size(397, 100);
		splitContainer2.Size = size;
		this.SplitContainer1.SplitterDistance = 56;
		this.SplitContainer1.TabIndex = 0;
		this.MessageRtb.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.MessageRtb.BorderStyle = System.Windows.Forms.BorderStyle.None;
		System.Windows.Forms.RichTextBox messageRtb = this.MessageRtb;
		location = new System.Drawing.Point(14, 12);
		messageRtb.Location = location;
		this.MessageRtb.Name = "MessageRtb";
		System.Windows.Forms.RichTextBox messageRtb2 = this.MessageRtb;
		size = new System.Drawing.Size(368, 30);
		messageRtb2.Size = size;
		this.MessageRtb.TabIndex = 0;
		this.MessageRtb.Text = "There are existing Appearances in the TimeLiner, do you want to keep, merge or replace them?";
		this.MergeBtn.DialogResult = System.Windows.Forms.DialogResult.Yes;
		System.Windows.Forms.Button mergeBtn = this.MergeBtn;
		location = new System.Drawing.Point(313, 6);
		mergeBtn.Location = location;
		this.MergeBtn.Name = "MergeBtn";
		System.Windows.Forms.Button mergeBtn2 = this.MergeBtn;
		size = new System.Drawing.Size(75, 23);
		mergeBtn2.Size = size;
		this.MergeBtn.TabIndex = 2;
		this.MergeBtn.Text = "&Merge";
		this.MainTT.SetToolTip(this.MergeBtn, "Merge Import items with existing ones, by adding\r\nnew items and modifying properties of existing ones\r\nto match imported with same name");
		this.MergeBtn.UseVisualStyleBackColor = true;
		this.ReplaceBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
		System.Windows.Forms.Button replaceBtn = this.ReplaceBtn;
		location = new System.Drawing.Point(232, 6);
		replaceBtn.Location = location;
		this.ReplaceBtn.Name = "ReplaceBtn";
		System.Windows.Forms.Button replaceBtn2 = this.ReplaceBtn;
		size = new System.Drawing.Size(75, 23);
		replaceBtn2.Size = size;
		this.ReplaceBtn.TabIndex = 3;
		this.ReplaceBtn.Text = "&Replace";
		this.MainTT.SetToolTip(this.ReplaceBtn, "Clear existing items and import new ones");
		this.ReplaceBtn.UseVisualStyleBackColor = true;
		this.SkipBtn.DialogResult = System.Windows.Forms.DialogResult.Ignore;
		System.Windows.Forms.Button skipBtn = this.SkipBtn;
		location = new System.Drawing.Point(151, 6);
		skipBtn.Location = location;
		this.SkipBtn.Name = "SkipBtn";
		System.Windows.Forms.Button skipBtn2 = this.SkipBtn;
		size = new System.Drawing.Size(75, 23);
		skipBtn2.Size = size;
		this.SkipBtn.TabIndex = 1;
		this.SkipBtn.Text = "&Skip";
		this.MainTT.SetToolTip(this.SkipBtn, "Skip this phase of the Import and continue with\r\nother items (Appearances, SimulationTaskTypes...)");
		this.SkipBtn.UseVisualStyleBackColor = true;
		this.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		System.Windows.Forms.Button cancelBtn = this.CancelBtn;
		location = new System.Drawing.Point(70, 6);
		cancelBtn.Location = location;
		this.CancelBtn.Name = "CancelBtn";
		System.Windows.Forms.Button cancelBtn2 = this.CancelBtn;
		size = new System.Drawing.Size(75, 23);
		cancelBtn2.Size = size;
		this.CancelBtn.TabIndex = 0;
		this.CancelBtn.Text = "&Cancel";
		this.MainTT.SetToolTip(this.CancelBtn, "Cancel the Import");
		this.CancelBtn.UseVisualStyleBackColor = true;
		this.FlowLayoutPanel1.Controls.Add(this.MergeBtn);
		this.FlowLayoutPanel1.Controls.Add(this.ReplaceBtn);
		this.FlowLayoutPanel1.Controls.Add(this.SkipBtn);
		this.FlowLayoutPanel1.Controls.Add(this.CancelBtn);
		this.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.FlowLayoutPanel flowLayoutPanel = this.FlowLayoutPanel1;
		location = new System.Drawing.Point(0, 0);
		flowLayoutPanel.Location = location;
		this.FlowLayoutPanel1.Name = "FlowLayoutPanel1";
		System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2 = this.FlowLayoutPanel1;
		System.Windows.Forms.Padding padding = new System.Windows.Forms.Padding(3);
		flowLayoutPanel2.Padding = padding;
		this.FlowLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
		System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3 = this.FlowLayoutPanel1;
		size = new System.Drawing.Size(397, 40);
		flowLayoutPanel3.Size = size;
		this.FlowLayoutPanel1.TabIndex = 4;
		System.Drawing.SizeF sizeF = new System.Drawing.SizeF(6f, 13f);
		this.AutoScaleDimensions = sizeF;
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		size = new System.Drawing.Size(397, 100);
		this.ClientSize = size;
		this.Controls.Add(this.SplitContainer1);
		this.Font = new System.Drawing.Font("Segoe UI", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
		this.MaximizeBox = false;
		this.MinimizeBox = false;
		this.Name = "ConfirmationUF";
		this.ShowIcon = false;
		this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Existing Appearances";
		this.SplitContainer1.Panel1.ResumeLayout(false);
		this.SplitContainer1.Panel2.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.SplitContainer1).EndInit();
		this.SplitContainer1.ResumeLayout(false);
		this.FlowLayoutPanel1.ResumeLayout(false);
		this.ResumeLayout(false);
	}

	public DialogResult ShowDialog(IWin32Window Owner, string Body, string Title)
	{
		Text = Title;
		Message = Body;
		return ShowDialog(Owner);
	}
}
