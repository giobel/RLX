using System;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Plugins;
using Autodesk.Navisworks.Api.Timeliner;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[Plugin("NWTimelinerUtils.TimeLinerConfigurationManagerAddin", "LORG")]
[AddInPlugin(/*Could not decode attribute arguments.*/)]
public class TimeLinerConfigurationManagerAddin : AddInPlugin
{
	private const string _AUTHENTICATOR_ADDIN_ID = "NWAuthenticator.AuthenticatorAddin.LORG";

	private const string _PLUGIN_ID = "NWTimelinerUtils.TimelinerAssistantPlugin.LORG";

	private const string _PLUGIN_DISPLAY_NAME = "Timeliner Configuration Manager";

	[DebuggerNonUserCode]
	public TimeLinerConfigurationManagerAddin()
	{
	}

	public override int Execute(params string[] parameters)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Expected O, but got Unknown
		int result;
		try
		{
			AddInPluginRecord val = (AddInPluginRecord)Application.Plugins.FindPlugin("NWAuthenticator.AuthenticatorAddin.LORG");
			string[] array = new string[2]
			{
				Conversions.ToString(-1),
				Conversions.ToString(23)
			};
			if (val == null)
			{
				result = NotifyUnlicensed();
			}
			else
			{
				int num = val.Execute(array);
				int num2 = Cipher.EncryptTime();
				if (num2 != num)
				{
					result = NotifyUnlicensed();
				}
				else
				{
					IOForm iOForm = new IOForm();
					iOForm.ShowDialog();
					result = -1;
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show("Error occurred when loading addin addin: Timeliner Configuration Manager:\r\n" + ex2.Message, "Addin error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			result = -2;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	private int NotifyUnlicensed()
	{
		MessageBox.Show(Application.Gui.MainWindow, "No valid licence found", "Licence missing", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		return 0;
	}

	public override CommandState CanExecute()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		CommandState val = ((AddInPlugin)this).CanExecute();
		if (Application.ActiveDocument == null || ((DocumentTimeliner)Application.ActiveDocument.Timeliner).TasksRoot.Children.Count == 0)
		{
			val.IsEnabled = false;
		}
		return val;
	}

	public override bool TryShowHelp()
	{
		bool result;
		try
		{
			Help.ShowHelp(null, "http://de-software.web/Plugins/Navisworks/Timeliner Utilities/Help/Timeliner Utilities.html#Timeliner Configuration Manager");
			result = true;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}
}
