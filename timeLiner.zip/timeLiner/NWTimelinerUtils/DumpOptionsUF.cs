using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.ComApi;
using Autodesk.Navisworks.Api.Interop.ComApi;
using Autodesk.Navisworks.Api.Timeliner;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using NWTimelinerUtils.My;
using NWTimelinerUtils.My.Resources;

namespace NWTimelinerUtils;

[DesignerGenerated]
public class DumpOptionsUF : Form
{
	private IContainer components;

	[AccessedThroughProperty("MainTT")]
	private ToolTip _MainTT;

	[AccessedThroughProperty("DumpBtn")]
	private Button _DumpBtn;

	[AccessedThroughProperty("AvailableFieldsCbx")]
	private CheckedListBox _AvailableFieldsCbx;

	[AccessedThroughProperty("SelectedFieldsCbx")]
	private ListBox _SelectedFieldsCbx;

	[AccessedThroughProperty("SplitContainer1")]
	private SplitContainer _SplitContainer1;

	[AccessedThroughProperty("GroupBox2")]
	private GroupBox _GroupBox2;

	[AccessedThroughProperty("SelectUnselectAllLlbl")]
	private LinkLabel _SelectUnselectAllLlbl;

	[AccessedThroughProperty("DeleteBtn")]
	private Button _DeleteBtn;

	[AccessedThroughProperty("DownBtn")]
	private Button _DownBtn;

	[AccessedThroughProperty("UpBtn")]
	private Button _UpBtn;

	[AccessedThroughProperty("FlowLayoutPanel1")]
	private FlowLayoutPanel _FlowLayoutPanel1;

	[AccessedThroughProperty("Panel1")]
	private Panel _Panel1;

	[AccessedThroughProperty("FlowLayoutPanel2")]
	private FlowLayoutPanel _FlowLayoutPanel2;

	[AccessedThroughProperty("GroupBox1")]
	private GroupBox _GroupBox1;

	[AccessedThroughProperty("DeletePreviousCbx")]
	private CheckBox _DeletePreviousCbx;

	[AccessedThroughProperty("TimeZoneCbx")]
	private CheckBox _TimeZoneCbx;

	[AccessedThroughProperty("OnlyTopLevelCbx")]
	private CheckBox _OnlyTopLevelCbx;

	private const string CAT_DUMP = "TimeLiner +";

	private const string PR_TIME_STAMP = "Dump Date";

	private const string PR_TASK_COUNT = "Tasks Count";

	private const string IDX_CHAR = " #";

	private const string SPLIT_CHAR = ";";

	private const string _MSG_TITLE_ERROR = "TimeLiner Dump Error";

	public TimeSpan STUPID_NAVISWORKS_DATE_OFFSET_TOLERANCE;

	private Progress p;

	internal virtual ToolTip MainTT
	{
		[DebuggerNonUserCode]
		get
		{
			return _MainTT;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_MainTT = value;
		}
	}

	internal virtual Button DumpBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _DumpBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = DumpBtn_Click;
			if (_DumpBtn != null)
			{
				_DumpBtn.Click -= value2;
			}
			_DumpBtn = value;
			if (_DumpBtn != null)
			{
				_DumpBtn.Click += value2;
			}
		}
	}

	internal virtual CheckedListBox AvailableFieldsCbx
	{
		[DebuggerNonUserCode]
		get
		{
			return _AvailableFieldsCbx;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			ItemCheckEventHandler value2 = AvailableFieldsCbx_ItemCheck;
			if (_AvailableFieldsCbx != null)
			{
				_AvailableFieldsCbx.ItemCheck -= value2;
			}
			_AvailableFieldsCbx = value;
			if (_AvailableFieldsCbx != null)
			{
				_AvailableFieldsCbx.ItemCheck += value2;
			}
		}
	}

	internal virtual ListBox SelectedFieldsCbx
	{
		[DebuggerNonUserCode]
		get
		{
			return _SelectedFieldsCbx;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = SelectedFieldsCbx_SelectedIndexChanged;
			if (_SelectedFieldsCbx != null)
			{
				_SelectedFieldsCbx.SelectedIndexChanged -= value2;
			}
			_SelectedFieldsCbx = value;
			if (_SelectedFieldsCbx != null)
			{
				_SelectedFieldsCbx.SelectedIndexChanged += value2;
			}
		}
	}

	internal virtual SplitContainer SplitContainer1
	{
		[DebuggerNonUserCode]
		get
		{
			return _SplitContainer1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_SplitContainer1 = value;
		}
	}

	internal virtual GroupBox GroupBox2
	{
		[DebuggerNonUserCode]
		get
		{
			return _GroupBox2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_GroupBox2 = value;
		}
	}

	internal virtual LinkLabel SelectUnselectAllLlbl
	{
		[DebuggerNonUserCode]
		get
		{
			return _SelectUnselectAllLlbl;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			LinkLabelLinkClickedEventHandler value2 = SelectUnselectAllLlbl_LinkClicked;
			if (_SelectUnselectAllLlbl != null)
			{
				_SelectUnselectAllLlbl.LinkClicked -= value2;
			}
			_SelectUnselectAllLlbl = value;
			if (_SelectUnselectAllLlbl != null)
			{
				_SelectUnselectAllLlbl.LinkClicked += value2;
			}
		}
	}

	internal virtual Button DeleteBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _DeleteBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = DeleteBtn_Click;
			if (_DeleteBtn != null)
			{
				_DeleteBtn.Click -= value2;
			}
			_DeleteBtn = value;
			if (_DeleteBtn != null)
			{
				_DeleteBtn.Click += value2;
			}
		}
	}

	internal virtual Button DownBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _DownBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = DownBtn_Click;
			if (_DownBtn != null)
			{
				_DownBtn.Click -= value2;
			}
			_DownBtn = value;
			if (_DownBtn != null)
			{
				_DownBtn.Click += value2;
			}
		}
	}

	internal virtual Button UpBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _UpBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = UpBtn_Click;
			if (_UpBtn != null)
			{
				_UpBtn.Click -= value2;
			}
			_UpBtn = value;
			if (_UpBtn != null)
			{
				_UpBtn.Click += value2;
			}
		}
	}

	internal virtual FlowLayoutPanel FlowLayoutPanel1
	{
		[DebuggerNonUserCode]
		get
		{
			return _FlowLayoutPanel1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_FlowLayoutPanel1 = value;
		}
	}

	internal virtual Panel Panel1
	{
		[DebuggerNonUserCode]
		get
		{
			return _Panel1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Panel1 = value;
		}
	}

	internal virtual FlowLayoutPanel FlowLayoutPanel2
	{
		[DebuggerNonUserCode]
		get
		{
			return _FlowLayoutPanel2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_FlowLayoutPanel2 = value;
		}
	}

	internal virtual GroupBox GroupBox1
	{
		[DebuggerNonUserCode]
		get
		{
			return _GroupBox1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_GroupBox1 = value;
		}
	}

	internal virtual CheckBox DeletePreviousCbx
	{
		[DebuggerNonUserCode]
		get
		{
			return _DeletePreviousCbx;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_DeletePreviousCbx = value;
		}
	}

	internal virtual CheckBox TimeZoneCbx
	{
		[DebuggerNonUserCode]
		get
		{
			return _TimeZoneCbx;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_TimeZoneCbx = value;
		}
	}

	internal virtual CheckBox OnlyTopLevelCbx
	{
		[DebuggerNonUserCode]
		get
		{
			return _OnlyTopLevelCbx;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_OnlyTopLevelCbx = value;
		}
	}

	public DumpOptionsUF()
	{
		base.Load += OptionsUF_Load;
		base.FormClosing += OptionsUF_FormClosing;
		ref TimeSpan sTUPID_NAVISWORKS_DATE_OFFSET_TOLERANCE = ref STUPID_NAVISWORKS_DATE_OFFSET_TOLERANCE;
		sTUPID_NAVISWORKS_DATE_OFFSET_TOLERANCE = new TimeSpan(0, 0, 2);
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NWTimelinerUtils.DumpOptionsUF));
		this.MainTT = new System.Windows.Forms.ToolTip(this.components);
		this.AvailableFieldsCbx = new System.Windows.Forms.CheckedListBox();
		this.SelectedFieldsCbx = new System.Windows.Forms.ListBox();
		this.DumpBtn = new System.Windows.Forms.Button();
		this.SplitContainer1 = new System.Windows.Forms.SplitContainer();
		this.GroupBox2 = new System.Windows.Forms.GroupBox();
		this.DeleteBtn = new System.Windows.Forms.Button();
		this.DownBtn = new System.Windows.Forms.Button();
		this.UpBtn = new System.Windows.Forms.Button();
		this.SelectUnselectAllLlbl = new System.Windows.Forms.LinkLabel();
		this.FlowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
		this.Panel1 = new System.Windows.Forms.Panel();
		this.FlowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
		this.OnlyTopLevelCbx = new System.Windows.Forms.CheckBox();
		this.TimeZoneCbx = new System.Windows.Forms.CheckBox();
		this.DeletePreviousCbx = new System.Windows.Forms.CheckBox();
		this.GroupBox1 = new System.Windows.Forms.GroupBox();
		((System.ComponentModel.ISupportInitialize)this.SplitContainer1).BeginInit();
		this.SplitContainer1.Panel1.SuspendLayout();
		this.SplitContainer1.Panel2.SuspendLayout();
		this.SplitContainer1.SuspendLayout();
		this.GroupBox2.SuspendLayout();
		this.FlowLayoutPanel1.SuspendLayout();
		this.Panel1.SuspendLayout();
		this.FlowLayoutPanel2.SuspendLayout();
		this.GroupBox1.SuspendLayout();
		this.SuspendLayout();
		this.MainTT.AutoPopDelay = 8000;
		this.MainTT.InitialDelay = 500;
		this.MainTT.ReshowDelay = 100;
		this.AvailableFieldsCbx.CheckOnClick = true;
		this.AvailableFieldsCbx.Dock = System.Windows.Forms.DockStyle.Fill;
		this.AvailableFieldsCbx.FormattingEnabled = true;
		this.AvailableFieldsCbx.IntegralHeight = false;
		this.AvailableFieldsCbx.Items.AddRange(new object[30]
		{
			"Display Name", "Planned Start Date", "Planned End Date", "Planned Duration", "Actual Start Date", "Actual End Date", "Actual Duration", "Progress Percent", "Task Status", "Planned vs Actual Start",
			"Planned vs Actual End", "Planned vs Actual Duration", "Equipment Cost", "Labor Cost", "Material Cost", "Subcontractor Cost", "Total Cost", "Display Id", "Synchronization Id", "Task Type",
			"User1", "User2", "User3", "User4", "User5", "User6", "User7", "User8", "User9", "User10"
		});
		System.Windows.Forms.CheckedListBox availableFieldsCbx = this.AvailableFieldsCbx;
		System.Drawing.Point location = new System.Drawing.Point(0, 0);
		availableFieldsCbx.Location = location;
		this.AvailableFieldsCbx.Name = "AvailableFieldsCbx";
		System.Windows.Forms.CheckedListBox availableFieldsCbx2 = this.AvailableFieldsCbx;
		System.Drawing.Size size = new System.Drawing.Size(299, 263);
		availableFieldsCbx2.Size = size;
		this.AvailableFieldsCbx.TabIndex = 1;
		this.MainTT.SetToolTip(this.AvailableFieldsCbx, "List of available fields to dump");
		this.SelectedFieldsCbx.Dock = System.Windows.Forms.DockStyle.Fill;
		this.SelectedFieldsCbx.FormattingEnabled = true;
		this.SelectedFieldsCbx.IntegralHeight = false;
		System.Windows.Forms.ListBox selectedFieldsCbx = this.SelectedFieldsCbx;
		location = new System.Drawing.Point(0, 0);
		selectedFieldsCbx.Location = location;
		this.SelectedFieldsCbx.Name = "SelectedFieldsCbx";
		this.SelectedFieldsCbx.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
		System.Windows.Forms.ListBox selectedFieldsCbx2 = this.SelectedFieldsCbx;
		size = new System.Drawing.Size(195, 263);
		selectedFieldsCbx2.Size = size;
		this.SelectedFieldsCbx.TabIndex = 2;
		this.MainTT.SetToolTip(this.SelectedFieldsCbx, "List of selected fields to dump (in order shown)");
		this.DumpBtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.DumpBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
		System.Windows.Forms.Button dumpBtn = this.DumpBtn;
		location = new System.Drawing.Point(426, 8);
		dumpBtn.Location = location;
		this.DumpBtn.Name = "DumpBtn";
		System.Windows.Forms.Button dumpBtn2 = this.DumpBtn;
		size = new System.Drawing.Size(75, 23);
		dumpBtn2.Size = size;
		this.DumpBtn.TabIndex = 0;
		this.DumpBtn.Text = "&Dump";
		this.DumpBtn.UseVisualStyleBackColor = true;
		this.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.SplitContainer splitContainer = this.SplitContainer1;
		location = new System.Drawing.Point(3, 53);
		splitContainer.Location = location;
		this.SplitContainer1.Name = "SplitContainer1";
		this.SplitContainer1.Panel1.Controls.Add(this.AvailableFieldsCbx);
		this.SplitContainer1.Panel2.Controls.Add(this.SelectedFieldsCbx);
		System.Windows.Forms.SplitContainer splitContainer2 = this.SplitContainer1;
		size = new System.Drawing.Size(498, 263);
		splitContainer2.Size = size;
		this.SplitContainer1.SplitterDistance = 299;
		this.SplitContainer1.TabIndex = 1;
		this.GroupBox2.Controls.Add(this.SplitContainer1);
		this.GroupBox2.Controls.Add(this.FlowLayoutPanel2);
		this.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.GroupBox groupBox = this.GroupBox2;
		location = new System.Drawing.Point(5, 96);
		groupBox.Location = location;
		this.GroupBox2.Name = "GroupBox2";
		System.Windows.Forms.GroupBox groupBox2 = this.GroupBox2;
		size = new System.Drawing.Size(504, 319);
		groupBox2.Size = size;
		this.GroupBox2.TabIndex = 2;
		this.GroupBox2.TabStop = false;
		this.GroupBox2.Text = "Fields";
		this.DeleteBtn.Enabled = false;
		this.DeleteBtn.Image = NWTimelinerUtils.My.Resources.Resources.Delete;
		System.Windows.Forms.Button deleteBtn = this.DeleteBtn;
		location = new System.Drawing.Point(123, 6);
		deleteBtn.Location = location;
		this.DeleteBtn.Name = "DeleteBtn";
		System.Windows.Forms.Button deleteBtn2 = this.DeleteBtn;
		size = new System.Drawing.Size(23, 23);
		deleteBtn2.Size = size;
		this.DeleteBtn.TabIndex = 4;
		this.DeleteBtn.UseVisualStyleBackColor = true;
		this.DownBtn.Enabled = false;
		this.DownBtn.Image = NWTimelinerUtils.My.Resources.Resources.Down;
		System.Windows.Forms.Button downBtn = this.DownBtn;
		location = new System.Drawing.Point(94, 6);
		downBtn.Location = location;
		this.DownBtn.Name = "DownBtn";
		System.Windows.Forms.Button downBtn2 = this.DownBtn;
		size = new System.Drawing.Size(23, 23);
		downBtn2.Size = size;
		this.DownBtn.TabIndex = 3;
		this.DownBtn.UseVisualStyleBackColor = true;
		this.UpBtn.Enabled = false;
		this.UpBtn.Image = NWTimelinerUtils.My.Resources.Resources.Up;
		System.Windows.Forms.Button upBtn = this.UpBtn;
		location = new System.Drawing.Point(65, 6);
		upBtn.Location = location;
		this.UpBtn.Name = "UpBtn";
		System.Windows.Forms.Button upBtn2 = this.UpBtn;
		size = new System.Drawing.Size(23, 23);
		upBtn2.Size = size;
		this.UpBtn.TabIndex = 2;
		this.UpBtn.UseVisualStyleBackColor = true;
		this.SelectUnselectAllLlbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
		this.SelectUnselectAllLlbl.AutoSize = true;
		this.SelectUnselectAllLlbl.LinkColor = System.Drawing.SystemColors.ControlDarkDark;
		System.Windows.Forms.LinkLabel selectUnselectAllLlbl = this.SelectUnselectAllLlbl;
		location = new System.Drawing.Point(6, 11);
		selectUnselectAllLlbl.Location = location;
		this.SelectUnselectAllLlbl.Name = "SelectUnselectAllLlbl";
		System.Windows.Forms.LinkLabel selectUnselectAllLlbl2 = this.SelectUnselectAllLlbl;
		size = new System.Drawing.Size(53, 13);
		selectUnselectAllLlbl2.Size = size;
		this.SelectUnselectAllLlbl.TabIndex = 8;
		this.SelectUnselectAllLlbl.TabStop = true;
		this.SelectUnselectAllLlbl.Text = "Select &All";
		this.SelectUnselectAllLlbl.VisitedLinkColor = System.Drawing.SystemColors.ControlDarkDark;
		this.FlowLayoutPanel1.AutoSize = true;
		this.FlowLayoutPanel1.Controls.Add(this.DumpBtn);
		this.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
		System.Windows.Forms.FlowLayoutPanel flowLayoutPanel = this.FlowLayoutPanel1;
		location = new System.Drawing.Point(0, 420);
		flowLayoutPanel.Location = location;
		this.FlowLayoutPanel1.Name = "FlowLayoutPanel1";
		System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2 = this.FlowLayoutPanel1;
		System.Windows.Forms.Padding padding = new System.Windows.Forms.Padding(5);
		flowLayoutPanel2.Padding = padding;
		this.FlowLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
		System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3 = this.FlowLayoutPanel1;
		size = new System.Drawing.Size(514, 39);
		flowLayoutPanel3.Size = size;
		this.FlowLayoutPanel1.TabIndex = 3;
		this.Panel1.BackColor = System.Drawing.SystemColors.Window;
		this.Panel1.Controls.Add(this.GroupBox2);
		this.Panel1.Controls.Add(this.GroupBox1);
		this.Panel1.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.Panel panel = this.Panel1;
		location = new System.Drawing.Point(0, 0);
		panel.Location = location;
		this.Panel1.Name = "Panel1";
		System.Windows.Forms.Panel panel2 = this.Panel1;
		padding = new System.Windows.Forms.Padding(5);
		panel2.Padding = padding;
		System.Windows.Forms.Panel panel3 = this.Panel1;
		size = new System.Drawing.Size(514, 420);
		panel3.Size = size;
		this.Panel1.TabIndex = 4;
		this.FlowLayoutPanel2.AutoSize = true;
		this.FlowLayoutPanel2.Controls.Add(this.SelectUnselectAllLlbl);
		this.FlowLayoutPanel2.Controls.Add(this.UpBtn);
		this.FlowLayoutPanel2.Controls.Add(this.DownBtn);
		this.FlowLayoutPanel2.Controls.Add(this.DeleteBtn);
		this.FlowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
		System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4 = this.FlowLayoutPanel2;
		location = new System.Drawing.Point(3, 18);
		flowLayoutPanel4.Location = location;
		this.FlowLayoutPanel2.Name = "FlowLayoutPanel2";
		System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5 = this.FlowLayoutPanel2;
		size = new System.Drawing.Size(498, 35);
		flowLayoutPanel5.Size = size;
		this.FlowLayoutPanel2.TabIndex = 9;
		this.OnlyTopLevelCbx.AutoSize = true;
		this.OnlyTopLevelCbx.Checked = NWTimelinerUtils.My.MySettings.Default.TOP_LEVEL_ONLY;
		this.OnlyTopLevelCbx.CheckState = System.Windows.Forms.CheckState.Checked;
		this.OnlyTopLevelCbx.DataBindings.Add(new System.Windows.Forms.Binding("Checked", NWTimelinerUtils.My.MySettings.Default, "TOP_LEVEL_ONLY", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
		System.Windows.Forms.CheckBox onlyTopLevelCbx = this.OnlyTopLevelCbx;
		location = new System.Drawing.Point(12, 42);
		onlyTopLevelCbx.Location = location;
		this.OnlyTopLevelCbx.Name = "OnlyTopLevelCbx";
		System.Windows.Forms.CheckBox onlyTopLevelCbx2 = this.OnlyTopLevelCbx;
		size = new System.Drawing.Size(244, 17);
		onlyTopLevelCbx2.Size = size;
		this.OnlyTopLevelCbx.TabIndex = 2;
		this.OnlyTopLevelCbx.Text = "Dump Properties only for top level Objects";
		this.MainTT.SetToolTip(this.OnlyTopLevelCbx, "Check if you only want to dump Porperties on\r\nObjects \"Attached to\". Objects \"Contained In\" (Objects\r\ndescendant of attached Objects) will not get the new\r\nProperty Tab");
		this.OnlyTopLevelCbx.UseVisualStyleBackColor = true;
		this.TimeZoneCbx.AutoSize = true;
		this.TimeZoneCbx.Checked = NWTimelinerUtils.My.MySettings.Default.TIME_ZONED;
		this.TimeZoneCbx.CheckState = System.Windows.Forms.CheckState.Checked;
		this.TimeZoneCbx.DataBindings.Add(new System.Windows.Forms.Binding("Checked", NWTimelinerUtils.My.MySettings.Default, "TIME_ZONED", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
		System.Windows.Forms.CheckBox timeZoneCbx = this.TimeZoneCbx;
		location = new System.Drawing.Point(12, 66);
		timeZoneCbx.Location = location;
		this.TimeZoneCbx.Name = "TimeZoneCbx";
		System.Windows.Forms.CheckBox timeZoneCbx2 = this.TimeZoneCbx;
		size = new System.Drawing.Size(202, 17);
		timeZoneCbx2.Size = size;
		this.TimeZoneCbx.TabIndex = 6;
		this.TimeZoneCbx.Text = "Local Timezone for Timeliner Dates";
		this.MainTT.SetToolTip(this.TimeZoneCbx, resources.GetString("TimeZoneCbx.ToolTip"));
		this.TimeZoneCbx.UseVisualStyleBackColor = true;
		this.DeletePreviousCbx.AutoSize = true;
		this.DeletePreviousCbx.Checked = NWTimelinerUtils.My.MySettings.Default.DELETE_PREVIOUS;
		this.DeletePreviousCbx.CheckState = System.Windows.Forms.CheckState.Checked;
		this.DeletePreviousCbx.DataBindings.Add(new System.Windows.Forms.Binding("Checked", NWTimelinerUtils.My.MySettings.Default, "DELETE_PREVIOUS", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
		System.Windows.Forms.CheckBox deletePreviousCbx = this.DeletePreviousCbx;
		location = new System.Drawing.Point(12, 19);
		deletePreviousCbx.Location = location;
		this.DeletePreviousCbx.Name = "DeletePreviousCbx";
		System.Windows.Forms.CheckBox deletePreviousCbx2 = this.DeletePreviousCbx;
		size = new System.Drawing.Size(261, 17);
		deletePreviousCbx2.Size = size;
		this.DeletePreviousCbx.TabIndex = 1;
		this.DeletePreviousCbx.Text = "Clean Previous Synchronization on all Objects";
		this.MainTT.SetToolTip(this.DeletePreviousCbx, "When Checked, the custom tab in the Properties Panel is\r\ncleared on all Objects before the Dump. When Unchecked,\r\nonly Objects that are found in the TimeLiner during the Dump\r\nare cleared");
		this.DeletePreviousCbx.UseVisualStyleBackColor = true;
		this.GroupBox1.Controls.Add(this.DeletePreviousCbx);
		this.GroupBox1.Controls.Add(this.TimeZoneCbx);
		this.GroupBox1.Controls.Add(this.OnlyTopLevelCbx);
		this.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top;
		System.Windows.Forms.GroupBox groupBox3 = this.GroupBox1;
		location = new System.Drawing.Point(5, 5);
		groupBox3.Location = location;
		this.GroupBox1.Name = "GroupBox1";
		System.Windows.Forms.GroupBox groupBox4 = this.GroupBox1;
		size = new System.Drawing.Size(504, 91);
		groupBox4.Size = size;
		this.GroupBox1.TabIndex = 1;
		this.GroupBox1.TabStop = false;
		this.GroupBox1.Text = "General";
		this.AcceptButton = this.DumpBtn;
		System.Drawing.SizeF sizeF = new System.Drawing.SizeF(6f, 13f);
		this.AutoScaleDimensions = sizeF;
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		size = new System.Drawing.Size(514, 459);
		this.ClientSize = size;
		this.Controls.Add(this.Panel1);
		this.Controls.Add(this.FlowLayoutPanel1);
		this.Font = new System.Drawing.Font("Segoe UI", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
		this.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		this.KeyPreview = true;
		this.MaximizeBox = false;
		this.MinimizeBox = false;
		this.Name = "DumpOptionsUF";
		this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Properties Dump Options";
		this.SplitContainer1.Panel1.ResumeLayout(false);
		this.SplitContainer1.Panel2.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.SplitContainer1).EndInit();
		this.SplitContainer1.ResumeLayout(false);
		this.GroupBox2.ResumeLayout(false);
		this.GroupBox2.PerformLayout();
		this.FlowLayoutPanel1.ResumeLayout(false);
		this.Panel1.ResumeLayout(false);
		this.FlowLayoutPanel2.ResumeLayout(false);
		this.FlowLayoutPanel2.PerformLayout();
		this.GroupBox1.ResumeLayout(false);
		this.GroupBox1.PerformLayout();
		this.ResumeLayout(false);
		this.PerformLayout();
	}

	private void OptionsUF_Load(object sender, EventArgs e)
	{
		try
		{
			if (MySettingsProperty.Settings.SELECTED_FIELDS == null)
			{
				return;
			}
			string[] array = MySettingsProperty.Settings.SELECTED_FIELDS.Split(';');
			string[] array2 = array;
			foreach (string value in array2)
			{
				int num = AvailableFieldsCbx.Items.IndexOf(value);
				if (num > -1)
				{
					AvailableFieldsCbx.SetItemChecked(num, value: true);
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(Common.NavisworksWin(), "The plugin cannot be loaded: " + ex2.Message, "TimeLiner Dump Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void DumpBtn_Click(object sender, EventArgs e)
	{
		try
		{
			DateTime utcNow = DateTime.UtcNow;
			DumpProperties(TimeStamp: new DateTime(utcNow.Year, utcNow.Month, utcNow.Day, utcNow.Hour, utcNow.Minute, utcNow.Second), CleanAll: DeletePreviousCbx.Checked, TopLevelOnly: OnlyTopLevelCbx.Checked, ReportProperties: SelectedFieldsString().Split(';'), TimeZoneOffset: TimeZoneCbx.Checked);
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show(Common.NavisworksWin(), "An error occurred when dumping properties: \r\n" + ex2.Message, "TimeLiner Dump Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void OptionsUF_FormClosing(object sender, FormClosingEventArgs e)
	{
		MySettingsProperty.Settings.SELECTED_FIELDS = SelectedFieldsString();
		MySettingsProperty.Settings.Save();
	}

	private void AvailableFieldsCbx_ItemCheck(object sender, ItemCheckEventArgs e)
	{
		string text = Conversions.ToString(AvailableFieldsCbx.Items[e.Index]);
		if (e.NewValue == CheckState.Checked)
		{
			if (SelectedFieldsCbx.Items.IndexOf(text) == -1)
			{
				SelectedFieldsCbx.Items.Add(text);
			}
		}
		else
		{
			int num = SelectedFieldsCbx.Items.IndexOf(text);
			if (num > -1)
			{
				SelectedFieldsCbx.Items.Remove(text);
			}
		}
		if (AvailableFieldsCbx.CheckedItems.Count == 1 && e.NewValue == CheckState.Unchecked)
		{
			SelectUnselectAllLlbl.Text = "Select &All";
		}
		else
		{
			SelectUnselectAllLlbl.Text = "Unselect &All";
		}
	}

	private void SelectUnselectAllLlbl_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		bool flag = Operators.CompareString(SelectUnselectAllLlbl.Text, "Select &All", TextCompare: false) == 0;
		checked
		{
			int num = AvailableFieldsCbx.Items.Count - 1;
			for (int i = 0; i <= num; i++)
			{
				if (AvailableFieldsCbx.GetItemChecked(i) != flag)
				{
					AvailableFieldsCbx.SetItemChecked(i, flag);
				}
			}
		}
	}

	private void SelectedFieldsCbx_SelectedIndexChanged(object sender, EventArgs e)
	{
		DeleteBtn.Enabled = SelectedFieldsCbx.SelectedItems.Count > 0;
		UpBtn.Enabled = ((SelectedFieldsCbx.SelectedItems.Count == 1 && SelectedFieldsCbx.SelectedIndex > 0) ? true : false);
		DownBtn.Enabled = ((SelectedFieldsCbx.SelectedItems.Count == 1 && SelectedFieldsCbx.SelectedIndex < checked(SelectedFieldsCbx.Items.Count - 1)) ? true : false);
	}

	private void DeleteBtn_Click(object sender, EventArgs e)
	{
		if (SelectedFieldsCbx.SelectedItems.Count == 0)
		{
			return;
		}
		checked
		{
			for (int i = SelectedFieldsCbx.Items.Count - 1; i >= 0; i += -1)
			{
				if (SelectedFieldsCbx.GetSelected(i))
				{
					int num = AvailableFieldsCbx.Items.IndexOf(RuntimeHelpers.GetObjectValue(SelectedFieldsCbx.Items[i]));
					if (num > -1)
					{
						AvailableFieldsCbx.SetItemChecked(num, value: false);
					}
					else
					{
						SelectedFieldsCbx.Items.RemoveAt(i);
					}
				}
			}
		}
	}

	private void UpBtn_Click(object sender, EventArgs e)
	{
		checked
		{
			if (SelectedFieldsCbx.SelectedItems.Count == 1 && SelectedFieldsCbx.SelectedIndex != 0)
			{
				int selectedIndex = SelectedFieldsCbx.SelectedIndex;
				object objectValue = RuntimeHelpers.GetObjectValue(SelectedFieldsCbx.SelectedItem);
				SelectedFieldsCbx.Items.Remove(RuntimeHelpers.GetObjectValue(objectValue));
				SelectedFieldsCbx.Items.Insert(selectedIndex - 1, RuntimeHelpers.GetObjectValue(objectValue));
				SelectedFieldsCbx.ClearSelected();
				SelectedFieldsCbx.SetSelected(selectedIndex - 1, value: true);
			}
		}
	}

	private void DownBtn_Click(object sender, EventArgs e)
	{
		checked
		{
			if (SelectedFieldsCbx.SelectedItems.Count == 1 && SelectedFieldsCbx.SelectedIndex != SelectedFieldsCbx.Items.Count - 1)
			{
				int selectedIndex = SelectedFieldsCbx.SelectedIndex;
				object objectValue = RuntimeHelpers.GetObjectValue(SelectedFieldsCbx.SelectedItem);
				SelectedFieldsCbx.Items.Remove(RuntimeHelpers.GetObjectValue(objectValue));
				SelectedFieldsCbx.Items.Insert(selectedIndex + 1, RuntimeHelpers.GetObjectValue(objectValue));
				SelectedFieldsCbx.ClearSelected();
				SelectedFieldsCbx.SetSelected(selectedIndex + 1, value: true);
			}
		}
	}

	public void DumpProperties(bool CleanAll, bool TopLevelOnly, string[] ReportProperties, bool TimeZoneOffset, DateTime TimeStamp)
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Expected O, but got Unknown
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Expected O, but got Unknown
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Expected O, but got Unknown
		Document activeDocument = Application.ActiveDocument;
		bool expression = false;
		checked
		{
			try
			{
				Visible = false;
				activeDocument.CurrentSelection.Clear();
				p = Application.BeginProgress("Dumping Timeliner Properties", "");
				p.BeginSubOperation(0.05, "Listing Tasks with attachment...");
				DocumentTimeliner val = (DocumentTimeliner)activeDocument.Timeliner;
				List<TimelinerTask> Tasks = new List<TimelinerTask>();
				foreach (TimelinerTask child in val.TasksRoot.Children)
				{
					TimelinerTask task = child;
					Extensions.GetChildren(task, ref Tasks, WithSelection: true);
				}
				int count = Tasks.Count;
				if (count == 0)
				{
					Application.EndProgress();
					MessageBox.Show("No Object were found attached to the TimeLiner.", "Timeliner Dump", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					return;
				}
				p.EndSubOperation();
				if (CleanAll)
				{
					Search val2 = new Search();
					val2.Locations = (SearchLocations)0;
					val2.PruneBelowMatch = false;
					Search val3 = val2;
					val3.Selection.SelectAll();
					val3.SearchConditions.Add(SearchCondition.HasCategoryByDisplayName("TimeLiner +"));
					ModelItemCollection val4 = val3.FindAll(activeDocument, false);
					p.BeginSubOperation(0.05, "Cleaning previous Dump: " + Conversions.ToString(val4.Count) + " Object(s)");
					int count2 = val4.Count;
					int num = 1;
					foreach (ModelItem item in val4)
					{
						if (p.IsCanceled)
						{
							return;
						}
						RemoveCategoryByName(item, "TimeLiner +");
						p.Update((double)num / (double)count2);
						num++;
					}
					p.EndSubOperation();
				}
				p.BeginSubOperation(1.0, Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(Conversions.ToString(count) + " Tasks ", " x Attachment "), Interaction.IIf(TopLevelOnly, "", " + Children")), " x "), ReportProperties.Length), " Properties: "), string.Join("; ", ReportProperties))));
				int num2 = 0;
				foreach (TimelinerTask item2 in Tasks)
				{
					DumpTaskProperties(item2, TopLevelOnly, ReportProperties, TimeZoneOffset, TimeStamp);
					num2++;
					p.Update((double)Math.Min(count, num2) / (double)count);
				}
				p.EndSubOperation();
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				throw ex2;
			}
			finally
			{
				if (p != null && !((NativeHandle)p).IsDisposed)
				{
					expression = p.IsCanceled;
					Application.EndProgress();
				}
				NewLateBinding.LateCall(null, typeof(MessageBox), "Show", new object[2]
				{
					RuntimeHelpers.GetObjectValue(Interaction.IIf(expression, "Operation Cancelled.", "Operation Complete.")),
					"Timeliner Dump"
				}, null, null, null, IgnoreReturn: true);
			}
		}
	}

	private void DumpTaskProperties(TimelinerTask Task, bool TopLevelOnly, string[] ReportProperties, bool TimeZoneOffset, DateTime TimeStamp)
	{
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		if (p.IsCanceled || Task.Selection.IsClear)
		{
			return;
		}
		List<object> list = new List<object>();
		foreach (string text in ReportProperties)
		{
			try
			{
				switch (text)
				{
				case "Display Name":
					list.Add(new DumpProperty(text, ((SavedItem)Task).DisplayName));
					break;
				case "Planned Start Date":
					list.Add(new DumpProperty(text, ToUtc((DateTime)Task.PlannedStartDate, TimeZoneOffset)));
					break;
				case "Planned End Date":
					list.Add(new DumpProperty(text, ToUtc((DateTime)Task.PlannedEndDate, TimeZoneOffset)));
					break;
				case "Planned Duration":
					list.Add(new DumpProperty(text, Task.PlannedDuration.ToString()));
					break;
				case "Actual Start Date":
					list.Add(new DumpProperty(text, ToUtc((DateTime)Task.ActualStartDate, TimeZoneOffset)));
					break;
				case "Actual End Date":
					list.Add(new DumpProperty(text, ToUtc((DateTime)Task.ActualEndDate, TimeZoneOffset)));
					break;
				case "Actual Duration":
					list.Add(new DumpProperty(text, Task.ActualDuration.ToString()));
					break;
				case "Progress Percent":
					list.Add(new DumpProperty(text, RuntimeHelpers.GetObjectValue(NotNull(Task.ProgressPercent, 0.0))));
					break;
				case "Task Status":
					list.Add(new DumpProperty(text, ((Enum)Task.TaskStatus).ToString()));
					break;
				case "Planned vs Actual Start":
				{
					DateTime? plannedEndDate = Task.ActualStartDate;
					bool hasValue3 = plannedEndDate.HasValue;
					DateTime? actualEndDate = Task.PlannedStartDate;
					TimeSpan? obj3;
					if (!(hasValue3 & actualEndDate.HasValue))
					{
						obj3 = null;
					}
					else
					{
						TimeSpan? actualDuration = plannedEndDate.GetValueOrDefault() - actualEndDate.GetValueOrDefault();
						obj3 = actualDuration;
					}
					TimeSpan? timeSpan2 = obj3;
					list.Add(new DumpProperty(text, timeSpan2.ToString()));
					break;
				}
				case "Planned vs Actual End":
				{
					DateTime? actualEndDate = Task.ActualEndDate;
					bool hasValue2 = actualEndDate.HasValue;
					DateTime? plannedEndDate = Task.PlannedEndDate;
					TimeSpan? obj2;
					if (!(hasValue2 & plannedEndDate.HasValue))
					{
						obj2 = null;
					}
					else
					{
						TimeSpan? actualDuration = actualEndDate.GetValueOrDefault() - plannedEndDate.GetValueOrDefault();
						obj2 = actualDuration;
					}
					TimeSpan? timeSpan2 = obj2;
					list.Add(new DumpProperty(text, timeSpan2.ToString()));
					break;
				}
				case "Planned vs Actual Duration":
				{
					TimeSpan? actualDuration = Task.ActualDuration;
					bool hasValue = actualDuration.HasValue;
					TimeSpan? plannedDuration = Task.PlannedDuration;
					TimeSpan? obj;
					if (!(hasValue & plannedDuration.HasValue))
					{
						obj = null;
					}
					else
					{
						TimeSpan? timeSpan = actualDuration.GetValueOrDefault() - plannedDuration.GetValueOrDefault();
						obj = timeSpan;
					}
					TimeSpan? timeSpan2 = obj;
					list.Add(new DumpProperty(text, timeSpan2.ToString()));
					break;
				}
				case "Equipment Cost":
					list.Add(new DumpProperty(text, RuntimeHelpers.GetObjectValue(NotNull(Task.EquipmentCost, 0.0))));
					break;
				case "Labor Cost":
					list.Add(new DumpProperty(text, RuntimeHelpers.GetObjectValue(NotNull(Task.LaborCost, 0.0))));
					break;
				case "Material Cost":
					list.Add(new DumpProperty(text, RuntimeHelpers.GetObjectValue(NotNull(Task.MaterialCost, 0.0))));
					break;
				case "Subcontractor Cost":
					list.Add(new DumpProperty(text, RuntimeHelpers.GetObjectValue(NotNull(Task.SubcontractorCost, 0.0))));
					break;
				case "Total Cost":
					list.Add(new DumpProperty(text, RuntimeHelpers.GetObjectValue(NotNull(Task.TotalCost, 0.0))));
					break;
				case "Display Id":
					list.Add(new DumpProperty(text, Task.DisplayId));
					break;
				case "Synchronization Id":
					list.Add(new DumpProperty(text, Task.SynchronizationId));
					break;
				case "Task Type":
					list.Add(new DumpProperty(text, Task.SimulationTaskTypeName));
					break;
				default:
					list.Add(new DumpProperty(text, RuntimeHelpers.GetObjectValue(GetPropertyValue(Task, text))));
					break;
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				list.Add(new DumpProperty(text, ex2.Message));
				ProjectData.ClearProjectError();
			}
		}
		ModelItemCollection selectedItems = Task.Selection.GetSelectedItems(Application.ActiveDocument);
		foreach (ModelItem item in selectedItems)
		{
			if (p.IsCanceled)
			{
				break;
			}
			DumpTaskPropertiesOnItem(list, item, TopLevelOnly, TimeStamp);
		}
	}

	private void DumpTaskPropertiesOnItem(List<object> TaskProperties, ModelItem mi, bool TopLevelOnly, DateTime TimeStamp)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Expected O, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected O, but got Unknown
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Expected O, but got Unknown
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Expected O, but got Unknown
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Expected O, but got Unknown
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Expected O, but got Unknown
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Expected O, but got Unknown
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Expected O, but got Unknown
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Expected O, but got Unknown
		InwOpState10 val = ComApiBridge.State;
		InwGUIPropertyNode2 val2 = (InwGUIPropertyNode2)val.GetGUIPropertyNode(ComApiBridge.ToInwOaPath(mi), true);
		InwOaPropertyVec val3 = (InwOaPropertyVec)val.ObjectFactory((nwEObjectType)39, (object)null, (object)null);
		InwGUIAttribute2 val4 = null;
		int num = 0;
		DataProperty val5 = mi.PropertyCategories.FindPropertyByDisplayName("TimeLiner +", "Dump Date");
		checked
		{
			if (val5 != null)
			{
				foreach (InwGUIAttribute2 item in val2.GUIAttributes())
				{
					InwGUIAttribute2 val6 = item;
					if (val6.UserDefined)
					{
						num++;
						if (Operators.CompareString(val6.ClassUserName, "TimeLiner +", TextCompare: false) == 0)
						{
							val4 = val6;
							break;
						}
					}
				}
			}
			if (val5 != null && val5.Value.ToDateTime() - TimeStamp < STUPID_NAVISWORKS_DATE_OFFSET_TOLERANCE)
			{
				int num2 = mi.PropertyCategories.FindPropertyByDisplayName("TimeLiner +", "Tasks Count").Value.ToInt32();
				foreach (InwOaProperty item2 in val4.Properties())
				{
					InwOaProperty val7 = item2;
					InwOaProperty val8 = (InwOaProperty)val.ObjectFactory((nwEObjectType)20, (object)null, (object)null);
					val8.name = val7.name;
					val8.UserName = val7.UserName;
					val8.value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Operators.CompareString(val7.UserName, "Tasks Count", TextCompare: false) == 0, num2 + 1, RuntimeHelpers.GetObjectValue(val7.value)));
					val3.Properties().Add((object)val8);
				}
				foreach (DumpProperty TaskProperty in TaskProperties)
				{
					InwOaProperty val9 = (InwOaProperty)val.ObjectFactory((nwEObjectType)20, (object)null, (object)null);
					val9.name = TaskProperty.Name + " #" + Conversions.ToString(num2 + 1);
					val9.UserName = TaskProperty.Name + " #" + Conversions.ToString(num2 + 1);
					val9.value = RuntimeHelpers.GetObjectValue(TaskProperty.Value);
					val3.Properties().Add((object)val9);
				}
			}
			else
			{
				InwOaProperty val10 = (InwOaProperty)val.ObjectFactory((nwEObjectType)20, (object)null, (object)null);
				val10.name = "Dump Date";
				val10.UserName = "Dump Date";
				val10.value = TimeStamp;
				val3.Properties().Add((object)val10);
				InwOaProperty val11 = (InwOaProperty)val.ObjectFactory((nwEObjectType)20, (object)null, (object)null);
				val11.name = "Tasks Count";
				val11.UserName = "Tasks Count";
				val11.value = 1;
				val3.Properties().Add((object)val11);
				foreach (DumpProperty TaskProperty2 in TaskProperties)
				{
					InwOaProperty val12 = (InwOaProperty)val.ObjectFactory((nwEObjectType)20, (object)null, (object)null);
					val12.name = TaskProperty2.Name;
					val12.UserName = TaskProperty2.Name;
					val12.value = RuntimeHelpers.GetObjectValue(TaskProperty2.Value);
					val3.Properties().Add((object)val12);
				}
			}
			val2.SetUserDefined(num, "TimeLiner +", "TimeLiner +", val3);
			if (TopLevelOnly)
			{
				return;
			}
			foreach (ModelItem child in mi.Children)
			{
				DumpTaskPropertiesOnItem(TaskProperties, child, TopLevelOnly, TimeStamp);
			}
		}
	}

	private void RemoveCategoryByName(ModelItem mi, string CategoryDisplayName)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Expected O, but got Unknown
		InwGUIPropertyNode2 val = (InwGUIPropertyNode2)ComApiBridge.State.GetGUIPropertyNode(ComApiBridge.ToInwOaPath(mi), true);
		int userCategoryIndex = GetUserCategoryIndex(mi, CategoryDisplayName);
		if (userCategoryIndex > -1)
		{
			val.RemoveUserDefined(userCategoryIndex);
		}
	}

	private int GetUserCategoryIndex(ModelItem mi, string CategoryDisplayName)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Expected O, but got Unknown
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Expected O, but got Unknown
		InwGUIPropertyNode2 val = (InwGUIPropertyNode2)ComApiBridge.State.GetGUIPropertyNode(ComApiBridge.ToInwOaPath(mi), true);
		int num = 0;
		foreach (InwGUIAttribute2 item in val.GUIAttributes())
		{
			InwGUIAttribute2 val2 = item;
			if (val2.UserDefined)
			{
				num = checked(num + 1);
				if (Operators.CompareString(val2.ClassUserName, CategoryDisplayName, TextCompare: false) == 0)
				{
					return num;
				}
			}
		}
		return -1;
	}

	[DebuggerStepThrough]
	private object NotNull(object Value, object DefaultIfNull)
	{
		if (Value == null)
		{
			return DefaultIfNull;
		}
		return Value;
	}

	[DebuggerStepThrough]
	private DateTime ToUtc(DateTime dt, bool IsLocal)
	{
		if (IsLocal)
		{
			DateTime time = new DateTime(dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second, dt.Millisecond, DateTimeKind.Local);
			return TimeZone.CurrentTimeZone.ToUniversalTime(time);
		}
		return dt;
	}

	private object GetPropertyValue(TimelinerTask t, string PropName)
	{
		PropertyInfo property = typeof(TimelinerTask).GetProperty(PropName);
		return property.GetValue(t, BindingFlags.GetProperty, null, null, null);
	}

	private string SelectedFieldsString()
	{
		string text = null;
		foreach (object item in SelectedFieldsCbx.Items)
		{
			object objectValue = RuntimeHelpers.GetObjectValue(item);
			if (Operators.CompareString(text, "", TextCompare: false) != 0)
			{
				text += ";";
			}
			text += objectValue.ToString();
		}
		return text;
	}
}
