using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace NWTimelinerUtils;

public class DumpProperty
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private object _Value;

	public string Name
	{
		[DebuggerNonUserCode]
		get;
		[DebuggerNonUserCode]
		set;
	}

	public object Value
	{
		[DebuggerNonUserCode]
		get
		{
			return _Value;
		}
		[DebuggerNonUserCode]
		set
		{
			_Value = RuntimeHelpers.GetObjectValue(value);
		}
	}

	public DumpProperty(string Name, object Value)
	{
		this.Name = Name;
		this.Value = RuntimeHelpers.GetObjectValue(Value);
	}
}
