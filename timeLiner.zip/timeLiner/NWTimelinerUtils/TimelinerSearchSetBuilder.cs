using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Xml;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.DocumentParts;
using Autodesk.Navisworks.Api.Timeliner;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

public class TimelinerSearchSetBuilder : XmlSerializable, INotifyPropertyChanged
{
	private BindingList<SearchFieldMapping> _Mappings;

	private string _NamingField;

	private string _TimelinerRoot;

	private bool _AsSelectionSets;

	public const string XML_ROOT_NAME = "TimelinerSearchSetBuilder";

	public const string XML_TIMELINER_ROOT = "TimelinerRoot";

	public const string XML_NAMING_FIELD = "NamingField";

	public const string XML_MAPPINGS = "Mappings";

	public BindingList<SearchFieldMapping> Mappings => _Mappings;

	public string NamingField
	{
		get
		{
			return _NamingField;
		}
		set
		{
			SetProperty(ref _NamingField, value, "NamingField");
		}
	}

	public string TimelinerRoot
	{
		get
		{
			return _TimelinerRoot;
		}
		set
		{
			SetProperty(ref _TimelinerRoot, value, "TimelinerRoot");
		}
	}

	public bool AsSelectionSets
	{
		get
		{
			return _AsSelectionSets;
		}
		set
		{
			SetProperty(ref _AsSelectionSets, value, "AsSelectionSets");
		}
	}

	public override string XML_ROOT => "TimelinerSearchSetBuilder";

	[method: DebuggerNonUserCode]
	public event PropertyChangedEventHandler PropertyChanged;

	public TimelinerSearchSetBuilder()
	{
		_Mappings = SearchFieldMapping.GetFields();
		_AsSelectionSets = false;
	}

	protected bool SetProperty<T>(ref T storage, T value, [CallerMemberName] string PropertyName = null)
	{
		if (object.Equals(storage, value))
		{
			return false;
		}
		storage = value;
		OnPropertyChanged(PropertyName);
		return true;
	}

	protected virtual void OnPropertyChanged([CallerMemberName] string PropertyName = null)
	{
		PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
	}

	public void MapSearchSets()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected O, but got Unknown
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected O, but got Unknown
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Expected O, but got Unknown
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Expected O, but got Unknown
		DocumentTimeliner val = (DocumentTimeliner)Application.ActiveDocument.Timeliner;
		GroupItem val2 = (GroupItem)((SavedItem)val.TasksRoot).CreateCopy();
		List<SavedItem> list = new List<SavedItem>();
		Progress val3 = null;
		try
		{
			TimelinerTask val4 = (TimelinerTask)((IEnumerable<SavedItem>)val2.Children).FirstOrDefault([SpecialName] [DebuggerStepThrough] (SavedItem a0) => ((VB_0024AnonymousDelegate_0<TimelinerTask, bool>)([SpecialName] (TimelinerTask t) => Operators.CompareString(((SavedItem)t).DisplayName, TimelinerRoot, TextCompare: false) == 0))((TimelinerTask)a0));
			if (val4 == null)
			{
				throw new ArgumentException($"Invalid timeliner root: {TimelinerRoot}. Choose a task that exists in the current Timeliner document.");
			}
			List<TimelinerTask> Tasks = new List<TimelinerTask>();
			Extensions.GetChildren(val4, ref Tasks, WithSelection: false);
			int num = 0;
			int count = Tasks.Count;
			val3 = Application.BeginProgress("Timeliner Sets: Building Search Sets", "Building Search Sets and assigning to tasks...");
			foreach (TimelinerTask item in Tasks)
			{
				string text = "";
				try
				{
					if (val3.IsCanceled)
					{
						throw new ArgumentException("Operation Cancelled");
					}
					text = ((SavedItem)item).DisplayName;
					SavedItem val5 = BuildSet(item);
					if (val5 != null)
					{
						list.Add(val5);
					}
				}
				catch (Exception ex)
				{
					ProjectData.SetProjectError(ex);
					Exception ex2 = ex;
					throw new ArgumentException(string.Format("Task: {0} | error: {1}\r\n" + ex2.Message));
				}
				num = checked(num + 1);
				val3.Update((double)num / (double)count);
			}
			FolderItem val6 = new FolderItem();
			((SavedItem)val6).DisplayName = $"{TimelinerRoot}_{DateAndTime.Now:yy-MM-dd-HHmm}";
			FolderItem val7 = val6;
			((GroupItem)val7).Children.AddRange((IEnumerable<SavedItem>)list);
			DocumentSelectionSets selectionSets = Application.ActiveDocument.SelectionSets;
			selectionSets.InsertCopy(((GroupItem)selectionSets.RootItem).Children.Count, (SavedItem)(object)val7);
		}
		finally
		{
			if (val3 != null && !((NativeHandle)val3).IsDisposed)
			{
				Application.EndProgress();
			}
		}
	}

	private SavedItem BuildSet(TimelinerTask task)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Expected O, but got Unknown
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Expected O, but got Unknown
		Search val = new Search();
		val.PruneBelowMatch = true;
		val.Locations = (SearchLocations)3;
		Search val2 = val;
		val2.Selection.SelectAll();
		List<List<SearchCondition>> list = new List<List<SearchCondition>>();
		checked
		{
			foreach (SearchFieldMapping mapping in Mappings)
			{
				if (!mapping.Use)
				{
					continue;
				}
				string text = Extensions.FieldValue(task, mapping.FieldName).ToString();
				string[] array = text.Split(',');
				if (list.Count == 0)
				{
					list.Add(new List<SearchCondition>());
				}
				List<List<SearchCondition>> list2 = new List<List<SearchCondition>>();
				int num = array.Count() - 1;
				for (int i = 0; i <= num; i++)
				{
					List<List<SearchCondition>> list3 = CloneGroups(list);
					foreach (List<SearchCondition> item in list3)
					{
						string value = array[i];
						SearchCondition fieldCondition = GetFieldCondition(mapping, value);
						if (fieldCondition != null)
						{
							item.Add(fieldCondition);
						}
					}
					list2.AddRange(list3);
				}
				list = list2;
			}
			int num2 = 0;
			foreach (List<SearchCondition> item2 in list)
			{
				if (item2.Count > 0)
				{
					val2.SearchConditions.AddGroup((IEnumerable<SearchCondition>)item2);
					num2++;
				}
			}
			if (num2 == 0)
			{
				return null;
			}
			SelectionSet val3 = new SelectionSet();
			((SavedItem)val3).DisplayName = Extensions.FieldValue(task, NamingField).ToString();
			SelectionSet val4 = val3;
			if (AsSelectionSets)
			{
				val4.CopyFrom(val2.FindAll(Application.ActiveDocument, true));
			}
			else
			{
				val4.CopyFrom(val2);
			}
			return (SavedItem)(object)val4;
		}
	}

	private List<SearchCondition> CloneGroup(List<SearchCondition> group)
	{
		return group.Select([SpecialName] (SearchCondition c) => c).ToList();
	}

	private List<List<SearchCondition>> CloneGroups(List<List<SearchCondition>> groups)
	{
		return groups.Select([SpecialName] (List<SearchCondition> g) => CloneGroup(g)).ToList();
	}

	private SearchCondition GetFieldCondition(SearchFieldMapping field, string value)
	{
		if (!string.IsNullOrEmpty(value))
		{
			SearchCondition val = SearchCondition.HasPropertyByDisplayName(field.CategoryName, field.PropertyName);
			switch (field.Mode)
			{
			case MappingMode.Equals:
				val = val.EqualValue(VariantData.FromDisplayString(value));
				break;
			case MappingMode.Contains:
				val = val.DisplayStringContains(value);
				break;
			case MappingMode.GreaterThan:
				val = val.CompareWith((SearchConditionComparison)11, VariantData.FromDouble(double.Parse(value)));
				break;
			case MappingMode.GreaterThanOrEqual:
				val = val.CompareWith((SearchConditionComparison)10, VariantData.FromDouble(double.Parse(value)));
				break;
			case MappingMode.LessThan:
				val = val.CompareWith((SearchConditionComparison)8, VariantData.FromDouble(double.Parse(value)));
				break;
			case MappingMode.LessThanOrEqual:
				val = val.CompareWith((SearchConditionComparison)9, VariantData.FromDouble(double.Parse(value)));
				break;
			}
			return val;
		}
		return null;
	}

	public override XmlElement ToXmlNamedElement(XmlDocumentEx xmlDoc, string rootName)
	{
		XmlElement xmlElement = xmlDoc.CreateElement(rootName);
		xmlElement.SetAttribute("NamingField", NamingField);
		xmlElement.SetAttribute("TimelinerRoot", TimelinerRoot);
		XmlElement xmlElement2 = xmlDoc.CreateElement("Mappings");
		foreach (SearchFieldMapping mapping in Mappings)
		{
			xmlElement2.AppendChild(mapping.ToXmlDefaultElement(xmlDoc));
		}
		xmlElement.AppendChild(xmlElement2);
		return xmlElement;
	}

	public override void LoadXmlElement(XmlElement Elt)
	{
		checked
		{
			foreach (XmlElement childNode in Elt.ChildNodes)
			{
				string name = childNode.Name;
				if (Operators.CompareString(name, "Mappings", TextCompare: false) == 0)
				{
					int num = _Mappings.Count - 1;
					for (int i = 0; i <= num; i++)
					{
						_Mappings[i].LoadXmlElement((XmlElement)childNode.ChildNodes[i]);
					}
				}
			}
			foreach (XmlAttribute attribute in Elt.Attributes)
			{
				string name2 = attribute.Name;
				if (Operators.CompareString(name2, "NamingField", TextCompare: false) == 0)
				{
					NamingField = attribute.Value;
				}
				else if (Operators.CompareString(name2, "TimelinerRoot", TextCompare: false) == 0)
				{
					TimelinerRoot = attribute.Value;
				}
			}
		}
	}
}
