using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[StandardModule]
internal sealed class TimelinerDumpHelpers
{
	public const string TIMELINER_DUMP_NAME = "Timeliner Dump";

	public const string TIMELINER_DUMP_HELP_ID = "http://de-software.web/Plugins/Navisworks/Timeliner Utilities/Help/Timeliner Utilities.html#Timeliner Dump";

	public const string TIMELINER_DUMP_MSG_TITLE = "Timeliner Dump";

	public const string TIMELINER_DUMP_MSG_TITLE_ERROR = "Timeliner Dump Error";
}
