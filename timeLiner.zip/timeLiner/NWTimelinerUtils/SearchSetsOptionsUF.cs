using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Timeliner;
using Microsoft.VisualBasic.CompilerServices;
using NWTimelinerUtils.My.Resources;

namespace NWTimelinerUtils;

[DesignerGenerated]
public class SearchSetsOptionsUF : Form
{
	private IContainer components;

	[AccessedThroughProperty("TableLayoutPanel1")]
	private TableLayoutPanel _TableLayoutPanel1;

	[AccessedThroughProperty("Label1")]
	private Label _Label1;

	[AccessedThroughProperty("RootsCB")]
	private ComboBox _RootsCB;

	[AccessedThroughProperty("FieldsDG")]
	private DataGridView _FieldsDG;

	[AccessedThroughProperty("CancelBtn")]
	private Button _CancelBtn;

	[AccessedThroughProperty("OKBtn")]
	private Button _OKBtn;

	[AccessedThroughProperty("Label2")]
	private Label _Label2;

	[AccessedThroughProperty("SetsNameCB")]
	private ComboBox _SetsNameCB;

	[AccessedThroughProperty("UseDGC")]
	private DataGridViewCheckBoxColumn _UseDGC;

	[AccessedThroughProperty("CategoryDGC")]
	private DataGridViewTextBoxColumn _CategoryDGC;

	[AccessedThroughProperty("PropertyDGC")]
	private DataGridViewTextBoxColumn _PropertyDGC;

	[AccessedThroughProperty("ModeDGC")]
	private DataGridViewComboBoxColumn _ModeDGC;

	[AccessedThroughProperty("FieldNameDGC")]
	private DataGridViewTextBoxColumn _FieldNameDGC;

	[AccessedThroughProperty("TableLayoutPanel2")]
	private TableLayoutPanel _TableLayoutPanel2;

	[AccessedThroughProperty("ToolStrip1")]
	private ToolStrip _ToolStrip1;

	[AccessedThroughProperty("ImportExportBtn")]
	private ToolStripDropDownButton _ImportExportBtn;

	[AccessedThroughProperty("SaveIDMatchBtn")]
	private ToolStripMenuItem _SaveIDMatchBtn;

	[AccessedThroughProperty("LoadIDMatchBtn")]
	private ToolStripMenuItem _LoadIDMatchBtn;

	[AccessedThroughProperty("AsSelectionSetsCBx")]
	private CheckBox _AsSelectionSetsCBx;

	private TimelinerSearchSetBuilder Builder;

	internal virtual TableLayoutPanel TableLayoutPanel1
	{
		[DebuggerNonUserCode]
		get
		{
			return _TableLayoutPanel1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_TableLayoutPanel1 = value;
		}
	}

	internal virtual Label Label1
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label1 = value;
		}
	}

	internal virtual ComboBox RootsCB
	{
		[DebuggerNonUserCode]
		get
		{
			return _RootsCB;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = RootsCB_SizeChanged;
			if (_RootsCB != null)
			{
				_RootsCB.SizeChanged -= value2;
			}
			_RootsCB = value;
			if (_RootsCB != null)
			{
				_RootsCB.SizeChanged += value2;
			}
		}
	}

	internal virtual DataGridView FieldsDG
	{
		[DebuggerNonUserCode]
		get
		{
			return _FieldsDG;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_FieldsDG = value;
		}
	}

	internal virtual Button CancelBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _CancelBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_CancelBtn = value;
		}
	}

	internal virtual Button OKBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _OKBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = OKBtn_Click;
			if (_OKBtn != null)
			{
				_OKBtn.Click -= value2;
			}
			_OKBtn = value;
			if (_OKBtn != null)
			{
				_OKBtn.Click += value2;
			}
		}
	}

	internal virtual Label Label2
	{
		[DebuggerNonUserCode]
		get
		{
			return _Label2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_Label2 = value;
		}
	}

	internal virtual ComboBox SetsNameCB
	{
		[DebuggerNonUserCode]
		get
		{
			return _SetsNameCB;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = SetsNameCB_SizeChanged;
			if (_SetsNameCB != null)
			{
				_SetsNameCB.SizeChanged -= value2;
			}
			_SetsNameCB = value;
			if (_SetsNameCB != null)
			{
				_SetsNameCB.SizeChanged += value2;
			}
		}
	}

	internal virtual DataGridViewCheckBoxColumn UseDGC
	{
		[DebuggerNonUserCode]
		get
		{
			return _UseDGC;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_UseDGC = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn CategoryDGC
	{
		[DebuggerNonUserCode]
		get
		{
			return _CategoryDGC;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_CategoryDGC = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn PropertyDGC
	{
		[DebuggerNonUserCode]
		get
		{
			return _PropertyDGC;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_PropertyDGC = value;
		}
	}

	internal virtual DataGridViewComboBoxColumn ModeDGC
	{
		[DebuggerNonUserCode]
		get
		{
			return _ModeDGC;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_ModeDGC = value;
		}
	}

	internal virtual DataGridViewTextBoxColumn FieldNameDGC
	{
		[DebuggerNonUserCode]
		get
		{
			return _FieldNameDGC;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_FieldNameDGC = value;
		}
	}

	internal virtual TableLayoutPanel TableLayoutPanel2
	{
		[DebuggerNonUserCode]
		get
		{
			return _TableLayoutPanel2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_TableLayoutPanel2 = value;
		}
	}

	internal virtual ToolStrip ToolStrip1
	{
		[DebuggerNonUserCode]
		get
		{
			return _ToolStrip1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_ToolStrip1 = value;
		}
	}

	internal virtual ToolStripDropDownButton ImportExportBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _ImportExportBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_ImportExportBtn = value;
		}
	}

	internal virtual ToolStripMenuItem SaveIDMatchBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _SaveIDMatchBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = SaveIDMatchBtn_Click;
			if (_SaveIDMatchBtn != null)
			{
				_SaveIDMatchBtn.Click -= value2;
			}
			_SaveIDMatchBtn = value;
			if (_SaveIDMatchBtn != null)
			{
				_SaveIDMatchBtn.Click += value2;
			}
		}
	}

	internal virtual ToolStripMenuItem LoadIDMatchBtn
	{
		[DebuggerNonUserCode]
		get
		{
			return _LoadIDMatchBtn;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = LoadIDMatchBtn_Click;
			if (_LoadIDMatchBtn != null)
			{
				_LoadIDMatchBtn.Click -= value2;
			}
			_LoadIDMatchBtn = value;
			if (_LoadIDMatchBtn != null)
			{
				_LoadIDMatchBtn.Click += value2;
			}
		}
	}

	internal virtual CheckBox AsSelectionSetsCBx
	{
		[DebuggerNonUserCode]
		get
		{
			return _AsSelectionSetsCBx;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_AsSelectionSetsCBx = value;
		}
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
		System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
		System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
		System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
		System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NWTimelinerUtils.SearchSetsOptionsUF));
		this.CancelBtn = new System.Windows.Forms.Button();
		this.OKBtn = new System.Windows.Forms.Button();
		this.TableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
		this.Label1 = new System.Windows.Forms.Label();
		this.RootsCB = new System.Windows.Forms.ComboBox();
		this.FieldsDG = new System.Windows.Forms.DataGridView();
		this.UseDGC = new System.Windows.Forms.DataGridViewCheckBoxColumn();
		this.CategoryDGC = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.PropertyDGC = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.ModeDGC = new System.Windows.Forms.DataGridViewComboBoxColumn();
		this.FieldNameDGC = new System.Windows.Forms.DataGridViewTextBoxColumn();
		this.Label2 = new System.Windows.Forms.Label();
		this.SetsNameCB = new System.Windows.Forms.ComboBox();
		this.AsSelectionSetsCBx = new System.Windows.Forms.CheckBox();
		this.TableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
		this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
		this.ImportExportBtn = new System.Windows.Forms.ToolStripDropDownButton();
		this.SaveIDMatchBtn = new System.Windows.Forms.ToolStripMenuItem();
		this.LoadIDMatchBtn = new System.Windows.Forms.ToolStripMenuItem();
		this.TableLayoutPanel1.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.FieldsDG).BeginInit();
		this.TableLayoutPanel2.SuspendLayout();
		this.ToolStrip1.SuspendLayout();
		this.SuspendLayout();
		this.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		System.Windows.Forms.Button cancelBtn = this.CancelBtn;
		System.Drawing.Point location = new System.Drawing.Point(492, 3);
		cancelBtn.Location = location;
		this.CancelBtn.Name = "CancelBtn";
		System.Windows.Forms.Button cancelBtn2 = this.CancelBtn;
		System.Drawing.Size size = new System.Drawing.Size(75, 23);
		cancelBtn2.Size = size;
		this.CancelBtn.TabIndex = 0;
		this.CancelBtn.Text = "&Cancel";
		this.CancelBtn.UseVisualStyleBackColor = true;
		this.OKBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
		System.Windows.Forms.Button oKBtn = this.OKBtn;
		location = new System.Drawing.Point(411, 3);
		oKBtn.Location = location;
		this.OKBtn.Name = "OKBtn";
		System.Windows.Forms.Button oKBtn2 = this.OKBtn;
		size = new System.Drawing.Size(75, 23);
		oKBtn2.Size = size;
		this.OKBtn.TabIndex = 1;
		this.OKBtn.Text = "&OK";
		this.OKBtn.UseVisualStyleBackColor = true;
		this.TableLayoutPanel1.ColumnCount = 2;
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
		this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100f));
		this.TableLayoutPanel1.Controls.Add(this.Label1, 0, 0);
		this.TableLayoutPanel1.Controls.Add(this.RootsCB, 1, 0);
		this.TableLayoutPanel1.Controls.Add(this.FieldsDG, 0, 3);
		this.TableLayoutPanel1.Controls.Add(this.Label2, 0, 1);
		this.TableLayoutPanel1.Controls.Add(this.SetsNameCB, 1, 1);
		this.TableLayoutPanel1.Controls.Add(this.AsSelectionSetsCBx, 1, 2);
		this.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel = this.TableLayoutPanel1;
		location = new System.Drawing.Point(0, 0);
		tableLayoutPanel.Location = location;
		this.TableLayoutPanel1.Name = "TableLayoutPanel1";
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel2 = this.TableLayoutPanel1;
		System.Windows.Forms.Padding padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
		tableLayoutPanel2.Padding = padding;
		this.TableLayoutPanel1.RowCount = 5;
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100f));
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
		this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20f));
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel3 = this.TableLayoutPanel1;
		size = new System.Drawing.Size(570, 513);
		tableLayoutPanel3.Size = size;
		this.TableLayoutPanel1.TabIndex = 1;
		this.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
		this.Label1.AutoSize = true;
		System.Windows.Forms.Label label = this.Label1;
		location = new System.Drawing.Point(3, 17);
		label.Location = location;
		this.Label1.Name = "Label1";
		System.Windows.Forms.Label label2 = this.Label1;
		padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
		label2.Padding = padding;
		System.Windows.Forms.Label label3 = this.Label1;
		size = new System.Drawing.Size(86, 13);
		label3.Size = size;
		this.Label1.TabIndex = 1;
		this.Label1.Text = "Timeliner Root";
		this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.RootsCB.Dock = System.Windows.Forms.DockStyle.Fill;
		this.RootsCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.RootsCB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
		this.RootsCB.FormattingEnabled = true;
		System.Windows.Forms.ComboBox rootsCB = this.RootsCB;
		location = new System.Drawing.Point(95, 13);
		rootsCB.Location = location;
		System.Windows.Forms.ComboBox rootsCB2 = this.RootsCB;
		padding = new System.Windows.Forms.Padding(3, 3, 5, 3);
		rootsCB2.Margin = padding;
		this.RootsCB.Name = "RootsCB";
		System.Windows.Forms.ComboBox rootsCB3 = this.RootsCB;
		size = new System.Drawing.Size(470, 21);
		rootsCB3.Size = size;
		this.RootsCB.TabIndex = 2;
		this.FieldsDG.AllowUserToAddRows = false;
		this.FieldsDG.AllowUserToDeleteRows = false;
		this.FieldsDG.AllowUserToResizeRows = false;
		dataGridViewCellStyle.BackColor = System.Drawing.Color.WhiteSmoke;
		this.FieldsDG.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
		this.FieldsDG.BackgroundColor = System.Drawing.SystemColors.Window;
		this.FieldsDG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.FieldsDG.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
		dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
		dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
		padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
		dataGridViewCellStyle2.Padding = padding;
		dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
		dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
		dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
		this.FieldsDG.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
		this.FieldsDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.FieldsDG.Columns.AddRange(this.UseDGC, this.CategoryDGC, this.PropertyDGC, this.ModeDGC, this.FieldNameDGC);
		this.TableLayoutPanel1.SetColumnSpan(this.FieldsDG, 2);
		this.FieldsDG.Dock = System.Windows.Forms.DockStyle.Fill;
		this.FieldsDG.GridColor = System.Drawing.SystemColors.Window;
		System.Windows.Forms.DataGridView fieldsDG = this.FieldsDG;
		location = new System.Drawing.Point(5, 92);
		fieldsDG.Location = location;
		System.Windows.Forms.DataGridView fieldsDG2 = this.FieldsDG;
		padding = new System.Windows.Forms.Padding(5);
		fieldsDG2.Margin = padding;
		this.FieldsDG.Name = "FieldsDG";
		this.FieldsDG.RowHeadersVisible = false;
		System.Windows.Forms.DataGridView fieldsDG3 = this.FieldsDG;
		size = new System.Drawing.Size(560, 416);
		fieldsDG3.Size = size;
		this.FieldsDG.TabIndex = 3;
		this.UseDGC.DataPropertyName = "Use";
		this.UseDGC.HeaderText = "Use";
		this.UseDGC.Name = "UseDGC";
		this.UseDGC.Width = 35;
		this.CategoryDGC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
		this.CategoryDGC.DataPropertyName = "CategoryName";
		padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
		dataGridViewCellStyle3.Padding = padding;
		this.CategoryDGC.DefaultCellStyle = dataGridViewCellStyle3;
		this.CategoryDGC.HeaderText = "Category";
		this.CategoryDGC.Name = "CategoryDGC";
		this.PropertyDGC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
		this.PropertyDGC.DataPropertyName = "PropertyName";
		padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
		dataGridViewCellStyle4.Padding = padding;
		this.PropertyDGC.DefaultCellStyle = dataGridViewCellStyle4;
		this.PropertyDGC.HeaderText = "Property";
		this.PropertyDGC.Name = "PropertyDGC";
		this.ModeDGC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.ModeDGC.DataPropertyName = "Mode";
		this.ModeDGC.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
		this.ModeDGC.DisplayStyleForCurrentCellOnly = true;
		this.ModeDGC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
		this.ModeDGC.HeaderText = "";
		this.ModeDGC.Name = "ModeDGC";
		this.ModeDGC.Resizable = System.Windows.Forms.DataGridViewTriState.True;
		this.ModeDGC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
		this.ModeDGC.Width = 19;
		this.FieldNameDGC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
		this.FieldNameDGC.DataPropertyName = "FieldName";
		padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
		dataGridViewCellStyle5.Padding = padding;
		this.FieldNameDGC.DefaultCellStyle = dataGridViewCellStyle5;
		this.FieldNameDGC.HeaderText = "Field";
		this.FieldNameDGC.Name = "FieldNameDGC";
		this.FieldNameDGC.Width = 57;
		this.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
		this.Label2.AutoSize = true;
		System.Windows.Forms.Label label4 = this.Label2;
		location = new System.Drawing.Point(3, 44);
		label4.Location = location;
		this.Label2.Name = "Label2";
		System.Windows.Forms.Label label5 = this.Label2;
		padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
		label5.Padding = padding;
		System.Windows.Forms.Label label6 = this.Label2;
		size = new System.Drawing.Size(65, 13);
		label6.Size = size;
		this.Label2.TabIndex = 4;
		this.Label2.Text = "Sets Name";
		this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
		this.SetsNameCB.Dock = System.Windows.Forms.DockStyle.Fill;
		this.SetsNameCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.SetsNameCB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
		this.SetsNameCB.FormattingEnabled = true;
		System.Windows.Forms.ComboBox setsNameCB = this.SetsNameCB;
		location = new System.Drawing.Point(95, 40);
		setsNameCB.Location = location;
		System.Windows.Forms.ComboBox setsNameCB2 = this.SetsNameCB;
		padding = new System.Windows.Forms.Padding(3, 3, 5, 3);
		setsNameCB2.Margin = padding;
		this.SetsNameCB.Name = "SetsNameCB";
		System.Windows.Forms.ComboBox setsNameCB3 = this.SetsNameCB;
		size = new System.Drawing.Size(470, 21);
		setsNameCB3.Size = size;
		this.SetsNameCB.TabIndex = 5;
		this.AsSelectionSetsCBx.AutoSize = true;
		System.Windows.Forms.CheckBox asSelectionSetsCBx = this.AsSelectionSetsCBx;
		location = new System.Drawing.Point(95, 67);
		asSelectionSetsCBx.Location = location;
		this.AsSelectionSetsCBx.Name = "AsSelectionSetsCBx";
		System.Windows.Forms.CheckBox asSelectionSetsCBx2 = this.AsSelectionSetsCBx;
		size = new System.Drawing.Size(220, 17);
		asSelectionSetsCBx2.Size = size;
		this.AsSelectionSetsCBx.TabIndex = 6;
		this.AsSelectionSetsCBx.Text = "Run Search and save as Selection Sets";
		this.AsSelectionSetsCBx.UseVisualStyleBackColor = true;
		this.TableLayoutPanel2.AutoSize = true;
		this.TableLayoutPanel2.ColumnCount = 4;
		this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
		this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100f));
		this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
		this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
		this.TableLayoutPanel2.Controls.Add(this.OKBtn, 2, 0);
		this.TableLayoutPanel2.Controls.Add(this.CancelBtn, 3, 0);
		this.TableLayoutPanel2.Controls.Add(this.ToolStrip1, 0, 0);
		this.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel4 = this.TableLayoutPanel2;
		location = new System.Drawing.Point(0, 513);
		tableLayoutPanel4.Location = location;
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel5 = this.TableLayoutPanel2;
		padding = new System.Windows.Forms.Padding(0);
		tableLayoutPanel5.Margin = padding;
		this.TableLayoutPanel2.Name = "TableLayoutPanel2";
		this.TableLayoutPanel2.RowCount = 1;
		this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100f));
		System.Windows.Forms.TableLayoutPanel tableLayoutPanel6 = this.TableLayoutPanel2;
		size = new System.Drawing.Size(570, 29);
		tableLayoutPanel6.Size = size;
		this.TableLayoutPanel2.TabIndex = 7;
		this.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Left;
		this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
		this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.ImportExportBtn });
		this.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
		System.Windows.Forms.ToolStrip toolStrip = this.ToolStrip1;
		location = new System.Drawing.Point(3, 0);
		toolStrip.Location = location;
		System.Windows.Forms.ToolStrip toolStrip2 = this.ToolStrip1;
		padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
		toolStrip2.Margin = padding;
		this.ToolStrip1.Name = "ToolStrip1";
		this.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
		System.Windows.Forms.ToolStrip toolStrip3 = this.ToolStrip1;
		size = new System.Drawing.Size(43, 29);
		toolStrip3.Size = size;
		this.ToolStrip1.TabIndex = 9;
		this.ToolStrip1.Text = "ToolStrip1";
		this.ImportExportBtn.AutoSize = false;
		this.ImportExportBtn.AutoToolTip = false;
		this.ImportExportBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
		this.ImportExportBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.SaveIDMatchBtn, this.LoadIDMatchBtn });
		this.ImportExportBtn.Image = NWTimelinerUtils.My.Resources.Resources.ImportExport;
		this.ImportExportBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
		this.ImportExportBtn.Name = "ImportExportBtn";
		this.ImportExportBtn.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
		System.Windows.Forms.ToolStripDropDownButton importExportBtn = this.ImportExportBtn;
		size = new System.Drawing.Size(40, 25);
		importExportBtn.Size = size;
		this.ImportExportBtn.Text = "I/O";
		this.SaveIDMatchBtn.Name = "SaveIDMatchBtn";
		System.Windows.Forms.ToolStripMenuItem saveIDMatchBtn = this.SaveIDMatchBtn;
		size = new System.Drawing.Size(139, 22);
		saveIDMatchBtn.Size = size;
		this.SaveIDMatchBtn.Text = "Save Config";
		this.LoadIDMatchBtn.Name = "LoadIDMatchBtn";
		System.Windows.Forms.ToolStripMenuItem loadIDMatchBtn = this.LoadIDMatchBtn;
		size = new System.Drawing.Size(139, 22);
		loadIDMatchBtn.Size = size;
		this.LoadIDMatchBtn.Text = "Load Config";
		this.AcceptButton = this.OKBtn;
		System.Drawing.SizeF sizeF = new System.Drawing.SizeF(6f, 13f);
		this.AutoScaleDimensions = sizeF;
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.CancelButton = this.CancelBtn;
		size = new System.Drawing.Size(570, 542);
		this.ClientSize = size;
		this.Controls.Add(this.TableLayoutPanel1);
		this.Controls.Add(this.TableLayoutPanel2);
		this.Font = new System.Drawing.Font("Segoe UI", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		this.Name = "SearchSetsOptionsUF";
		this.Text = "Timeliner Search Sets Generation";
		this.TableLayoutPanel1.ResumeLayout(false);
		this.TableLayoutPanel1.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.FieldsDG).EndInit();
		this.TableLayoutPanel2.ResumeLayout(false);
		this.TableLayoutPanel2.PerformLayout();
		this.ToolStrip1.ResumeLayout(false);
		this.ToolStrip1.PerformLayout();
		this.ResumeLayout(false);
		this.PerformLayout();
	}

	public SearchSetsOptionsUF(TimelinerSearchSetBuilder config)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Expected O, but got Unknown
		InitializeComponent();
		Builder = config;
		DocumentTimeliner val = (DocumentTimeliner)Application.ActiveDocument.Timeliner;
		string[] array = (from t in ((IEnumerable<SavedItem>)val.TasksRoot.Children).Select((Func<SavedItem, TimelinerTask>)([SpecialName] (SavedItem t) => (TimelinerTask)t))
			select ((SavedItem)t).DisplayName).ToArray();
		if (array.Length == 0)
		{
			throw new ArgumentException("No task found in the Timeliner for transfer.");
		}
		RootsCB.DataSource = array;
		RootsCB.SelectedItem = Builder.TimelinerRoot;
		RootsCB.DataBindings.Add("SelectedItem", Builder, "TimelinerRoot", formattingEnabled: true, DataSourceUpdateMode.OnPropertyChanged);
		SetsNameCB.DataSource = SearchFieldMapping.TaskSearchFields;
		SetsNameCB.SelectedItem = Builder.NamingField;
		SetsNameCB.DataBindings.Add("SelectedItem", Builder, "NamingField", formattingEnabled: true, DataSourceUpdateMode.OnPropertyChanged);
		AsSelectionSetsCBx.Checked = Builder.AsSelectionSets;
		AsSelectionSetsCBx.DataBindings.Add("Checked", Builder, "AsSelectionSets");
		ModeDGC.DataSource = Enum.GetValues(typeof(MappingMode));
		FieldsDG.AutoGenerateColumns = false;
		FieldsDG.DataSource = Builder.Mappings;
	}

	private void OKBtn_Click(object sender, EventArgs e)
	{
		try
		{
			Builder.MapSearchSets();
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show("Search sets mapping error.\r\n" + ex2.Message, "Timeliner Sets Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void SaveIDMatchBtn_Click(object sender, EventArgs e)
	{
		try
		{
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.DefaultExt = ".xml";
			saveFileDialog.AddExtension = true;
			using SaveFileDialog saveFileDialog2 = saveFileDialog;
			if (saveFileDialog2.ShowDialog() == DialogResult.OK)
			{
				Builder.SaveAs(saveFileDialog2.FileName);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show("Configuration cannot be saved.\r\n" + ex2.Message, "Timeliner Sets Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void LoadIDMatchBtn_Click(object sender, EventArgs e)
	{
		try
		{
			using OpenFileDialog openFileDialog = new OpenFileDialog();
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				Builder.LoadFile(openFileDialog.FileName);
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show("Configuration cannot be loaded.\r\n" + ex2.Message, "Timeliner Sets Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}

	private void SetsNameCB_SizeChanged(object sender, EventArgs e)
	{
		SetsNameCB.Refresh();
	}

	private void RootsCB_SizeChanged(object sender, EventArgs e)
	{
		RootsCB.Refresh();
	}
}
