using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[StandardModule]
internal sealed class TimelinerSearchSetsHelpers
{
	public const string TIMELINER_SETS_NAME = "Timeliner Sets";

	public const string TIMELINER_SETS_HELP_ID = "http://de-software.web/Plugins/Navisworks/Timeliner Utilities/Help/Timeliner Utilities.html#Timeliner Sets";

	public const string TIMELINER_SETS_MSG_TITLE = "Timeliner Sets";

	public const string TIMELINER_SETS_MSG_TITLE_ERROR = "Timeliner Sets Error";
}
