using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[StandardModule]
internal sealed class TimelinerAssistantHelpers
{
	public const string TIMELINER_PA_NAME = "Timeliner Assistant";

	public const string TIMELINER_PA_HELP_ID = "http://de-software.web/Plugins/Navisworks/Timeliner Utilities/Help/Timeliner Utilities.html#Timeliner Assistant";

	public const string TIMELINER_PA_MSG_TITLE = "Timeliner Assistant";

	public const string TIMELINER_PA_MSG_TITLE_ERROR = "Timeliner Assistant Error";
}
