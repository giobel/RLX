using System;
using System.Diagnostics;
using System.IO;
using System.Xml;

namespace NWTimelinerUtils;

public abstract class XmlSerializable
{
	public abstract string XML_ROOT { get; }

	[DebuggerNonUserCode]
	protected XmlSerializable()
	{
	}

	public void SaveAs(string path)
	{
		XmlDocumentEx xmlDocumentEx = ToXmlDoc();
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		using XmlWriter w = XmlWriter.Create(path, new XmlWriterSettings
		{
			Indent = true,
			IndentChars = "\t"
		});
		xmlDocumentEx.Save(w);
	}

	public XmlDocumentEx ToXmlDoc()
	{
		XmlDocumentEx xmlDocumentEx = new XmlDocumentEx();
		XmlElement newChild = ToXmlDefaultElement(xmlDocumentEx);
		xmlDocumentEx.AppendChild(newChild);
		return xmlDocumentEx;
	}

	public XmlElement ToXmlDefaultElement(XmlDocumentEx xmlDoc)
	{
		return ToXmlNamedElement(xmlDoc, XML_ROOT);
	}

	public abstract XmlElement ToXmlNamedElement(XmlDocumentEx xmlDoc, string rootName);

	public string ToXmlString()
	{
		return ToXmlDoc().OuterXml;
	}

	public void LoadFile(string filePath)
	{
		XmlDocumentEx xmlDocumentEx = new XmlDocumentEx();
		xmlDocumentEx.Load(filePath);
		LoadXmlDoc(xmlDocumentEx);
	}

	public void LoadXmlDoc(XmlDocumentEx XmlDoc)
	{
		XmlElement xmlElement = (XmlElement)XmlDoc.GetElementsByTagName(XML_ROOT)[0];
		if (xmlElement == null)
		{
			throw new ArgumentException($"No valid node found in the xml for {GetType().Name} deserialization. Requires node \"{XML_ROOT}\"");
		}
		LoadXmlElement(xmlElement);
	}

	public abstract void LoadXmlElement(XmlElement Elt);

	public void LoadXmlString(string xmlString)
	{
		XmlDocumentEx xmlDocumentEx = new XmlDocumentEx();
		xmlDocumentEx.LoadXml(xmlString);
		LoadXmlDoc(xmlDocumentEx);
	}
}
