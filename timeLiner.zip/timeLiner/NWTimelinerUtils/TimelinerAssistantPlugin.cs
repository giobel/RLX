using System;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Navisworks.Api.Plugins;
using Microsoft.VisualBasic.CompilerServices;
using NWTimelinerUtils.My;

namespace NWTimelinerUtils;

[DockPanePlugin(230, 230, FixedSize = false, AutoScroll = true, MinimumWidth = 230, MinimumHeight = 230)]
[Plugin("NWTimelinerUtils.TimelinerAssistantPlugin", "LORG", DisplayName = "Timeliner Assistant", ToolTip = "Extended function for the Timeliner")]
public class TimelinerAssistantPlugin : DockPanePlugin
{
	[DebuggerNonUserCode]
	public TimelinerAssistantPlugin()
	{
	}

	public override Control CreateControlPane()
	{
		TimelinerAssistantControl timelinerAssistantControl = new TimelinerAssistantControl();
		timelinerAssistantControl.Dock = DockStyle.Fill;
		timelinerAssistantControl.CreateControl();
		return timelinerAssistantControl;
	}

	public override void DestroyControlPane(Control pane)
	{
		MySettingsProperty.Settings.Save();
		pane.Dispose();
	}

	public override bool TryShowHelp()
	{
		bool result;
		try
		{
			Help.ShowHelp(null, "http://de-software.web/Plugins/Navisworks/Timeliner Utilities/Help/Timeliner Utilities.html#Timeliner Assistant");
			result = true;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}
}
