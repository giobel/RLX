using System.Diagnostics;
using System.Xml;
using Autodesk.Navisworks.Api;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

public class XmlDocumentEx : XmlDocument
{
	[DebuggerNonUserCode]
	public XmlDocumentEx()
	{
	}

	public new XmlElement CreateElement(string Name, string Value)
	{
		XmlElement xmlElement = CreateElement(Name);
		xmlElement.InnerText = Value;
		return xmlElement;
	}

	public new XmlElement CreateElement(string NodeName, string AttributeName, string AttributeValue)
	{
		XmlElement xmlElement = CreateElement(NodeName);
		xmlElement.SetAttribute(AttributeName, AttributeValue);
		return xmlElement;
	}

	public XmlElement CreateElement(string NodeName, string Value, string AttributeName, string AttributeValue)
	{
		XmlElement xmlElement = CreateElement(NodeName, Value);
		xmlElement.SetAttribute(AttributeName, AttributeValue);
		return xmlElement;
	}

	public object CreateColorElement(string Name, Color AdskColor)
	{
		XmlElement xmlElement = CreateElement(Name);
		xmlElement.SetAttribute("red", Conversions.ToString(AdskColor.R));
		xmlElement.SetAttribute("green", Conversions.ToString(AdskColor.G));
		xmlElement.SetAttribute("blue", Conversions.ToString(AdskColor.B));
		return xmlElement;
	}
}
