namespace NWTimelinerUtils;

public enum MappingMode
{
	Equals,
	Contains,
	GreaterThan,
	GreaterThanOrEqual,
	LessThan,
	LessThanOrEqual
}
