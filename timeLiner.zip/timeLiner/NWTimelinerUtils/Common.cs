using System.Windows.Forms;
using Autodesk.Navisworks.Api;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[StandardModule]
public sealed class Common
{
	public const string TIMELINER_UTILITIES = "Timeliner Utilities";

	public const string nl = "\r\n";

	public static string mnl(int cnt = 2)
	{
		string text = "";
		for (int i = 1; i <= cnt; i = checked(i + 1))
		{
			text += "\r\n";
		}
		return text;
	}

	public static IWin32Window NavisworksWin()
	{
		return Application.Gui.MainWindow;
	}
}
