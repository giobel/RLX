using System;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Plugins;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[AddInPlugin(/*Could not decode attribute arguments.*/)]
[Plugin("NWTimelinerUtils.TimelinerAssistantAddin", "LORG")]
public class TimelinerAssistantAddin : AddInPlugin
{
	private const string _AUTHENTICATOR_ADDIN_ID = "NWAuthenticator.AuthenticatorAddin.LORG";

	private const string _PLUGIN_ID = "NWTimelinerUtils.TimelinerAssistantPlugin.LORG";

	private const string _PLUGIN_DISPLAY_NAME = "Timeliner Assistant";

	[DebuggerNonUserCode]
	public TimelinerAssistantAddin()
	{
	}

	public override int Execute(params string[] parameters)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Expected O, but got Unknown
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Expected O, but got Unknown
		int result;
		try
		{
			AddInPluginRecord val = (AddInPluginRecord)Application.Plugins.FindPlugin("NWAuthenticator.AuthenticatorAddin.LORG");
			string[] array = new string[2]
			{
				Conversions.ToString(-1),
				Conversions.ToString(23)
			};
			if (val == null)
			{
				result = NotifyUnlicensed();
			}
			else
			{
				int num = val.Execute(array);
				int num2 = Cipher.EncryptTime();
				if (num2 != num)
				{
					result = NotifyUnlicensed();
				}
				else
				{
					PluginRecord val2 = Application.Plugins.FindPlugin("NWTimelinerUtils.TimelinerAssistantPlugin.LORG");
					if (val2 != null && val2 is DockPanePluginRecord && val2.IsEnabled)
					{
						if (val2.LoadedPlugin == null)
						{
							val2.LoadPlugin();
						}
						DockPanePlugin val3 = (DockPanePlugin)val2.LoadedPlugin;
						if (val3 != null)
						{
							val3.Visible = !val3.Visible;
						}
					}
					result = -1;
				}
			}
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			MessageBox.Show("Error occurred when loading addin addin: Timeliner Assistant:\r\n" + ex2.Message, "Addin error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			result = -2;
			ProjectData.ClearProjectError();
		}
		return result;
	}

	private int NotifyUnlicensed()
	{
		MessageBox.Show(Application.Gui.MainWindow, "No valid licence found", "Licence missing", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		return 0;
	}

	public override CommandState CanExecute()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Expected O, but got Unknown
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		PluginRecord val = Application.Plugins.FindPlugin("NWTimelinerUtils.TimelinerAssistantPlugin.LORG");
		bool isChecked = val != null && val is DockPanePluginRecord && val.IsEnabled && val.LoadedPlugin != null && ((DockPanePlugin)val.LoadedPlugin).Visible;
		CommandState val2 = new CommandState();
		val2.IsEnabled = true;
		val2.IsChecked = isChecked;
		return val2;
	}

	public override bool TryShowHelp()
	{
		bool result;
		try
		{
			Help.ShowHelp(null, "http://de-software.web/Plugins/Navisworks/Timeliner Utilities/Help/Timeliner Utilities.html#Timeliner Assistant");
			result = true;
		}
		catch (Exception ex)
		{
			ProjectData.SetProjectError(ex);
			Exception ex2 = ex;
			result = false;
			ProjectData.ClearProjectError();
		}
		return result;
	}
}
