using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace NWTimelinerUtils;

[StandardModule]
internal sealed class Cipher
{
	private static string _PassPhrase = "initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)";

	private static string _SaltValue = "Encoding.UTF8.GetBytes(plainText)";

	private static int _Iterations = 100;

	private static string _InitializationVector = "kogon7Asd584AKDz";

	private static int _KeySize = 256;

	internal static int EncryptTime()
	{
		byte[] bytes = Encoding.ASCII.GetBytes(_InitializationVector);
		byte[] bytes2 = Encoding.ASCII.GetBytes(_SaltValue);
		Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(_PassPhrase, bytes2, _Iterations);
		byte[] bytes3 = rfc2898DeriveBytes.GetBytes(checked((int)Math.Round((double)_KeySize / 8.0)));
		RijndaelManaged rijndaelManaged = new RijndaelManaged();
		rijndaelManaged.Mode = CipherMode.CBC;
		RijndaelManaged rijndaelManaged2 = rijndaelManaged;
		ICryptoTransform transform = rijndaelManaged2.CreateEncryptor(bytes3, bytes);
		byte[] array;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			using CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
			byte[] bytes4 = Encoding.UTF8.GetBytes(DateAndTime.Now.ToUniversalTime().ToShortTimeString());
			cryptoStream.Write(bytes4, 0, bytes4.Length);
			cryptoStream.FlushFinalBlock();
			array = memoryStream.ToArray();
			if (BitConverter.IsLittleEndian)
			{
				Array.Reverse(array);
			}
		}
		return BitConverter.ToInt32(array, 0);
	}
}
