using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("Laing O'Rourke")]
[assembly: AssemblyCopyright("Copyright © Laing O'Rourke 2018")]
[assembly: AssemblyTitle("NWTimelinerUtils for N24")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: AssemblyProduct("NWTimelinerUtils")]
[assembly: AssemblyDescription("Tools for Navisworks Timeliner")]
[assembly: Guid("4b82a8a7-21f3-424a-9557-81264b10e1c8")]
[assembly: AssemblyFileVersion("1.8.6.0")]
[assembly: AssemblyVersion("1.8.6.0")]
