using System.Diagnostics;
using System.Runtime.CompilerServices;

[DebuggerDisplay("<generated method>", Type = "<generated method>")]
[CompilerGenerated]
internal delegate TResult VB_0024AnonymousDelegate_0<TArg0, TResult>(TArg0 t);
